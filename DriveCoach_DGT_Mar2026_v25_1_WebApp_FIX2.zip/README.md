# DriveCoach DGT — v10

## Novetats
- Motor d'esdeveniments amb timestamp i GPS.
- Evidències temporals vinculades a incidències DGT.
- Gravació multimèdia segons les capacitats del navegador.
- Anàlisi local: recompte E/D/L, repeticions, àrees amb més incidències i recomanacions.

L'anàlisi local és una capa preparatòria: no és un model d'IA extern i no substitueix el criteri del professor.

Per càmera, micròfon i GPS, utilitza un entorn HTTPS o localhost compatible amb les APIs del navegador.


## v11 — Alumnes i evolució
- Historial local per alumne.
- Registre de sessions E/D/L.
- Resum d'evolució i gràfic de tendència.

## V12.1 — Mapa d'habilitats
Aquesta versió incorpora una capa pedagògica interna que associa cada incidència DGT de la base de març de 2026 amb una o més de 9 competències: Observació; Canvis de direcció/desplaçaments; Senyalització; Circulació; Distàncies; Maneig del vehicle; Maniobres; Presa de decisions; Seguretat.

La classificació és pròpia de DriveCoach i no forma part del barem oficial de la DGT. La font DGT i els llindars del barem es mantenen sense modificar.


## V14 — Motor pedagògic local
- Anàlisi local de l'historial per competències.
- Prioritats i recomanacions deterministes per a la propera sessió.
- Detecció de patrons persistents.
- Sense API externa, servidor ni enviament de dades.


## V15
Assistent del professor local durant la sessió: genera feedback contextual a partir de la darrera incidència i les competències associades. No utilitza API ni envia dades a Internet.


## V17 · Evidència temporal
Cada incidència registrada durant la prova inclou una finestra temporal de ±10 s (`evidenceWindow`) i es mostra en una cronologia local. La gravació completa es pot reproduir des de la incidència. La V17 no envia dades a serveis externs ni crea encara clips físics retallats; prepara la capa temporal per al futur motor de clips.


## V19 — Anàlisi d'evidència local
V19 afegeix una anàlisi estructurada local de les incidències i una guia per revisar l'evidència temporal. No fa afirmacions sobre el contingut visual del vídeo ni envia dades a serveis externs.


## V20 — Preparador multimodal local
Construeix i exporta un paquet JSON local amb incidències, finestres temporals, competències, GPS, disponibilitat multimèdia i contracte de seguretat per a una futura IA. No envia dades a Internet.


## V22 — Motor de context en temps real
Calcul local de context (fase, temps objectiu, GPS, incidència, competència i patró) amb intervenció sota control explícit del professor. No hi ha connexió amb serveis d'IA externs.


## V25 Stable — Tancament funcional
- Consentiment d'enregistrament amb vídeo i àudio separables.
- Firma manuscrita de l'alumne amb dit o llapis tàctil sobre canvas.
- Registre local de firma, data/hora, opcions autoritzades, mètode i versió del formulari.
- La gravació no s'autoritza sense firma.
- Informe de l'alumne i reproducció de gravacions es mantenen.
- Assistent en temps real sota control del professor.
- Castellà per defecte i català opcional per a la veu.
- Sense connexió a IA externa en aquesta versió.

## V25 Stable — Web App / PWA
La V25 es pot publicar com a web app instal·lable. Inclou manifest, Service Worker i icones. Per càmera, micròfon i GPS s'ha d'utilitzar HTTPS o localhost.
