# DriveCoach DGT V25 Stable — Web App / PWA

## Què és
Aquesta carpeta és una web app estàtica instal·lable (PWA). No necessita Node.js ni un servidor propi per executar la lògica de l'aplicació.

## Important
Per a càmera, micròfon i GPS cal obrir-la en **HTTPS** o en `localhost`. No facis servir `file://` per a les proves multimèdia.

## Opció recomanada: Netlify Drop
1. Descomprimeix aquest ZIP.
2. Entra a https://app.netlify.com/drop
3. Arrossega **la carpeta que conté `index.html`** a la zona de càrrega.
4. Netlify et donarà una adreça HTTPS.
5. Obre-la al mòbil.
6. Al navegador tria **Instal·lar app / Afegir a pantalla d'inici**.

## Alternativa: GitHub Pages
1. Crea un repositori nou a GitHub.
2. Puja tots els fitxers d'aquesta carpeta mantenint les rutes.
3. Activa Settings → Pages → Deploy from branch → `main` → `/root`.
4. Obre l'adreça HTTPS que et dona GitHub Pages.

## Prova inicial
- Obre la web en Chrome/Edge.
- Comprova que apareix l'opció d'instal·lar-la.
- Prova GPS.
- Prova càmera i micròfon.
- Prova el consentiment amb firma.
- Crea una sessió de prova.
- Registra E/D/L.
- Finalitza i comprova l'informe.
- Comprova que les dades locals persisteixen després de tancar i tornar a obrir.

## Limitació actual
La gravació multimèdia depèn de les APIs i limitacions del navegador/dispositiu. En particular, dos fluxos de càmera simultanis poden no estar disponibles en alguns mòbils.

## Seguretat
La V25 no connecta cap IA externa. La PWA no converteix automàticament les dades en un servei al núvol. Tot el que l'aplicació desa localment continua depenent de l'emmagatzematge del navegador/dispositiu.
