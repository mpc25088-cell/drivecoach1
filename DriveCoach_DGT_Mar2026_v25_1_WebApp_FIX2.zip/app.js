const state={data:null,faults:[],events:[],sessionStarted:null,examStarted:null,examFinished:null,timer:null,selectedSeverity:null,phase:'prep',durationMinutes:25,minimumReached:false,gpsWatchId:null,gpsTrack:[],lastPosition:null,gpsError:null,voice:{enabled:true,auto:true,language:'es',verbosity:'short',cooldownSec:8,lastAt:0,lastKey:''},media:{active:false,streams:[],recorders:[],chunks:{interior:[],exterior:[]},blobs:{interior:null,exterior:null},clips:{},startedAt:null,stoppedAt:null},consent:{student:'',video:false,audio:false,report:false,name:'',timestamp:null,version:1}};
const $=s=>document.querySelector(s);const $$=s=>[...document.querySelectorAll(s)];
function makeId(){try{if(globalThis.crypto&&typeof globalThis.crypto.randomUUID==='function')return globalThis.makeId()}catch{}return 'dc-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,10)}
const escapeHtml=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const severityText=s=>s==='E'?'ELIMINATÒRIA':s==='D'?'DEFICIENT':'LLEU';
const SKILL_META={OBS:['👀','Observació'],CAN:['🔄','Canvis de direcció / desplaçaments'],SIG:['🚦','Senyalització'],CIR:['🛣️','Circulació'],DIS:['↔️','Distàncies'],MAN:['⚙️','Maneig del vehicle'],PAR:['🅿️','Maniobres'],DEC:['🧠','Presa de decisions'],SEG:['⚠️','Seguretat']};
function skillTags(keys=[]){return (keys||[]).map(k=>SKILL_META[k]?`<span class="skill-tag" title="Competència pedagògica associada">${SKILL_META[k][0]} ${SKILL_META[k][1]}</span>`:'').join('')}

function playTone(s){try{const C=window.AudioContext||window.webkitAudioContext;if(!C)return;const a=new C(),o=a.createOscillator(),g=a.createGain();o.connect(g);g.connect(a.destination);o.frequency.value=s==='E'?180:s==='D'?420:720;o.type='sine';g.gain.setValueAtTime(.05,a.currentTime);g.gain.exponentialRampToValueAtTime(.001,a.currentTime+.16);o.start();o.stop(a.currentTime+.16)}catch{}}
function save(){localStorage.setItem('drivecoach-session',JSON.stringify({student:$('#student').value,licence:$('#licence').value,faults:state.faults,events:state.events,sessionStarted:state.sessionStarted,examStarted:state.examStarted,examFinished:state.examFinished,phase:state.phase,durationMinutes:state.durationMinutes,minimumReached:state.minimumReached,gpsTrack:state.gpsTrack,lastPosition:state.lastPosition,voice:state.voice,consent:state.consent}))}
function addFault(fault,c){if(state.phase!=='driving'){alert('Inicia la prova abans de registrar incidències.');return}const now=Date.now();const rel=Math.max(0,Math.floor((now-state.examStarted)/1000));const evidenceWindow={startSec:Math.max(0,rel-10),endSec:rel+10};const event={id:makeId(),type:'fault',time:now,relativeSec:rel,severity:fault.severity,code:c.code,title:c.title,text:fault.text,section:c.section,skills:Array.isArray(fault.skills)?fault.skills.slice():[],position:state.lastPosition?{...state.lastPosition}:null,observation:'',evidenceWindow,media:{audio:true,videoInterior:state.media.recorders.some(x=>x.key==='interior'),videoExterior:state.media.recorders.some(x=>x.key==='exterior'),mediaRelativeSec:state.media.startedAt?Math.max(0,Math.floor((now-state.media.startedAt)/1000)):null}};state.faults.push(event);state.events.push(event);playTone(fault.severity);save();renderFaults();renderCounters();renderSkillMap();renderEventStatus();renderEvidence();renderMediaTimeline();assistantRecommendation();voiceAfterFault(event);renderDrivingContext();}
function openPicker(sev){if(state.phase!=='driving'){alert('La prova encara no està en curs.');return}state.selectedSeverity=sev;$('#picker').classList.remove('hidden');$('#pickerTitle').textContent=`Selecciona una falta ${severityText(sev)}`;$('#search').value='';render();$('#picker').scrollIntoView({behavior:'smooth',block:'start'})}
function renderSections(){const s=$('#sectionFilter'),sections=[...new Set(state.data.criteria.map(x=>x.section).filter(Boolean))];s.innerHTML='<option value="all">Tots els blocs</option>'+sections.map(x=>`<option value="${escapeHtml(x)}">${escapeHtml(x)}</option>`).join('')}
function filteredCriteria(){const q=$('#search').value.toLowerCase().trim(),sec=$('#sectionFilter').value,sev=state.selectedSeverity;return state.data.criteria.map(c=>({...c,faults:c.faults.filter(f=>!sev||f.severity===sev)})).filter(c=>{if(!c.faults.length)return false;if(sec!=='all'&&c.section!==sec)return false;const all=c.faults.map(f=>f.text).concat([c.code,c.title,c.section,...c.notes]).join(' ').toLowerCase();return !q||all.includes(q)})}
function render(){const wrap=$('#criteria');wrap.innerHTML='';if(!state.selectedSeverity){wrap.innerHTML='<div class="empty">Tria E, D o L per començar.</div>';return}const cs=filteredCriteria();$('#pickerCount').textContent=`${cs.reduce((n,c)=>n+c.faults.length,0)} faltes disponibles`;cs.forEach(c=>{const el=document.createElement('article');el.className='criterion';el.innerHTML=`<div class="criterion-head"><strong class="code">${escapeHtml(c.code)}</strong><span class="title">${escapeHtml(c.title)}</span><small class="section">${escapeHtml(c.section||'')}</small></div><div class="fault-options">${c.faults.map(f=>`<button class="fault-option ${f.severity}" data-id="${escapeHtml(f.id)}"><span>${f.severity}</span><div><b>${escapeHtml(f.text)}</b><div class="skill-tags">${skillTags(f.skills)}</div></div></button>`).join('')}</div>`;el.querySelectorAll('.fault-option').forEach(b=>b.onclick=()=>{const f=c.faults.find(x=>x.id===b.dataset.id);if(f){addFault(f,c);$('#picker').classList.add('hidden')}});wrap.appendChild(el)});if(!wrap.children.length)wrap.innerHTML='<div class="empty">No hi ha coincidències.</div>'}
function renderFaults(){const el=$('#faults');$('#undo').disabled=!state.faults.length;if(!state.faults.length){el.className='empty';el.textContent='Encara no hi ha incidències.';renderEvidence();return}el.className='fault-list';el.innerHTML=state.faults.slice().reverse().map(f=>`<article class="fault ${f.severity}"><div class="fault-top"><div><b>${f.severity} · ${severityText(f.severity)}</b><small>${new Date(f.time).toLocaleTimeString('ca-ES')} · +${formatDuration(f.relativeSec)}</small></div><button class="remove" data-id="${f.id}">Eliminar</button></div><div><b>${escapeHtml(f.code)}</b> · ${escapeHtml(f.title)}</div><p>${escapeHtml(f.text)}</p><div class="skill-tags">${skillTags(f.skills)}</div><small>Evidència: −10 s / +10 s · ${f.position?`GPS ±${Math.round(f.position.accuracy||0)} m`:'sense GPS'}</small></article>`).join('');el.querySelectorAll('.remove').forEach(b=>b.onclick=()=>{state.faults=state.faults.filter(f=>f.id!==b.dataset.id);state.events=state.events.filter(e=>e.id!==b.dataset.id);save();renderFaults();renderCounters();renderSkillMap();renderEventStatus();renderEvidence()})}
function renderEvidence(){const host=$('#evidenceList');if(!host)return;if(!state.faults.length){host.innerHTML='<div class="empty">Quan registris una falta, aquí apareixerà la seva finestra d’evidència.</div>';return}host.innerHTML=state.faults.slice().reverse().map(f=>`<article class="evidence-item"><div><b>${f.severity} · ${escapeHtml(f.code)}</b><span>+${formatDuration(f.relativeSec)}</span></div><p>${escapeHtml(f.text)}</p><div class="skill-tags">${skillTags(f.skills)}</div><small>Finestra d’evidència: ${formatDuration(f.evidenceWindow.startSec)} → ${formatDuration(f.evidenceWindow.endSec)} · ${f.position?'GPS associat':'GPS no disponible'}</small><div class="evidence-actions"><button class="secondary" data-ev="${f.id}">▶ Veure evidència</button></div></article>`).join('');host.querySelectorAll('[data-ev]').forEach(b=>b.onclick=()=>prepareEvidence(b.dataset.ev))}
function mediaOffsetSec(){return state.media.startedAt&&state.examStarted?Math.max(0,(state.media.startedAt-state.examStarted)/1000):0}
function prepareEvidence(id){const f=state.faults.find(x=>x.id===id);if(!f)return;const modal=$('#evidenceViewer');modal.classList.remove('hidden');$('#viewerMeta').textContent=`${f.severity} · ${f.code} · +${formatDuration(f.relativeSec)} · ${f.text}`;const start=f.evidenceWindow.startSec,end=f.evidenceWindow.endSec;const len=Math.max(1,end-start);$('#evidenceSeek').min=0;$('#evidenceSeek').max=len;$('#evidenceSeek').value=Math.min(len,Math.max(0,f.relativeSec-start));$('#viewerStart').textContent=formatDuration(start);$('#viewerEnd').textContent=formatDuration(end);const vi=$('#evidenceInterior'),ve=$('#evidenceExterior'),au=$('#evidenceAudio');const hasI=!!state.media.blobs.interior,hasE=!!state.media.blobs.exterior;if(hasI){const u=URL.createObjectURL(state.media.blobs.interior);vi.src=u;au.src=u;vi.dataset.url=u;au.dataset.url=u}else{vi.removeAttribute('src');au.removeAttribute('src')}if(hasE){const u=URL.createObjectURL(state.media.blobs.exterior);ve.src=u;ve.dataset.url=u}else{ve.removeAttribute('src')}const notice=hasI||hasE?'V18: pots reproduir la finestra i generar un clip físic de l’interval sobre la gravació finalitzada. El clip es crea localment al dispositiu.':'Encara no hi ha una gravació finalitzada associada. Atura l’enregistrament per poder crear l’evidència.';$('#viewerNotice').textContent=notice;const actions=$('.viewer-actions');if(actions){actions.innerHTML='<button id="playEvidence" class="primary">▶ Reproduir evidència</button><button id="clipInterior" class="secondary">🎬 Crear clip interior</button><button id="clipExterior" class="secondary">🎬 Crear clip exterior</button><button id="downloadEvidenceInfo" class="secondary">⬇ Exportar fitxa</button>'}$('#playEvidence').onclick=()=>{const pos=Math.max(0,f.relativeSec-mediaOffsetSec());[vi,ve,au].forEach(x=>{try{x.currentTime=pos}catch{}});[vi,ve].filter(x=>x.src).forEach(x=>x.play().catch(()=>{}))};$('#evidenceSeek').oninput=()=>{const t=start+Number($('#evidenceSeek').value);const mediaPos=Math.max(0,t-mediaOffsetSec());[vi,ve,au].forEach(x=>{try{x.currentTime=mediaPos}catch{}})};$('#clipInterior').onclick=()=>createEvidenceClip(f,'interior');$('#clipExterior').onclick=()=>createEvidenceClip(f,'exterior');$('#downloadEvidenceInfo').onclick=()=>downloadEvidenceInfo(f);$('#clipInterior').disabled=!hasI;$('#clipExterior').disabled=!hasE}
async function createEvidenceClip(f,key){const blob=state.media.blobs[key];if(!blob){alert(`No hi ha gravació ${key==='interior'?'interior':'exterior'} disponible.`);return}const btn=$('#clip'+(key==='interior'?'Interior':'Exterior'));if(btn)btn.disabled=true;$('#viewerNotice').textContent='Creant clip local…';try{const v=document.createElement('video');v.muted=key!=='interior';v.playsInline=true;v.preload='auto';const src=URL.createObjectURL(blob);v.src=src;await new Promise((res,rej)=>{v.onloadedmetadata=()=>res();v.onerror=()=>rej(new Error('No s’ha pogut obrir la gravació.'))});const offset=mediaOffsetSec();let a=Math.max(0,f.evidenceWindow.startSec-offset),b=Math.min(v.duration||f.evidenceWindow.endSec-offset,f.evidenceWindow.endSec-offset);if(!Number.isFinite(a))a=0;if(!Number.isFinite(b)||b<=a)b=Math.min(v.duration||20,a+20);a=Math.max(0,Math.min(a,v.duration||a));b=Math.max(a+0.2,Math.min(b,v.duration||b));v.currentTime=a;await new Promise(res=>{const done=()=>{v.removeEventListener('seeked',done);res()};v.addEventListener('seeked',done,{once:true})});const stream=v.captureStream?v.captureStream():null;if(!stream)throw new Error('Aquest navegador no permet crear clips locals a partir de la gravació.');const mime=mediaMime();const rec=new MediaRecorder(stream,mime?{mimeType:mime}:undefined);const chunks=[];rec.ondataavailable=e=>{if(e.data.size)chunks.push(e.data)};const stopped=new Promise(res=>rec.onstop=res);rec.start(250);await v.play();await new Promise(res=>{const check=()=>{if(v.currentTime>=b){try{v.pause()}catch{};try{rec.stop()}catch{};res()}else setTimeout(check,80)};check()});await stopped;stream.getTracks().forEach(t=>t.stop());const out=new Blob(chunks,{type:rec.mimeType||'video/webm'});state.media.clips[f.id+':'+key]={blob:out,startSec:f.evidenceWindow.startSec,endSec:f.evidenceWindow.endSec,key,createdAt:Date.now()};downloadBlob(out,`DriveCoach_clip_${f.code.replace(/[^a-z0-9_-]+/gi,'_')}_${f.relativeSec}s_${key}.webm`);$('#viewerNotice').textContent=`Clip ${key==='interior'?'interior':'exterior'} creat localment · ${formatDuration(f.evidenceWindow.startSec)} → ${formatDuration(f.evidenceWindow.endSec)}.`;URL.revokeObjectURL(src)}catch(e){$('#viewerNotice').textContent='No s’ha pogut crear el clip en aquest navegador. La reproducció de la finestra continua disponible.';alert(e.message||'Error en crear el clip.')}finally{if(btn)btn.disabled=false}}
function downloadEvidenceInfo(f){const payload={app:'DriveCoach',version:'V18',type:'evidence',fault:f,recordingWindow:f.evidenceWindow,media:{interior:Boolean(state.media.blobs.interior),exterior:Boolean(state.media.blobs.exterior),clips:Object.keys(state.media.clips||{}).filter(k=>k.startsWith(f.id+':')).map(k=>({key:state.media.clips[k].key,startSec:state.media.clips[k].startSec,endSec:state.media.clips[k].endSec,createdAt:new Date(state.media.clips[k].createdAt).toISOString()}))}};const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'});downloadBlob(blob,`DriveCoach_evidencia_${f.code.replace(/[^a-z0-9_-]+/gi,'_')}_${f.relativeSec}s.json`)}

function closeEvidence(){const modal=$('#evidenceViewer');['evidenceInterior','evidenceExterior','evidenceAudio'].forEach(id=>{const x=$('#'+id);try{x.pause()}catch{};if(x.dataset.url){URL.revokeObjectURL(x.dataset.url);delete x.dataset.url}});modal.classList.add('hidden')}

function renderSkillMap(){
 const host=$('#skillMap'); if(!host||!state.data)return;
 const all=Object.keys(SKILL_META).map(k=>({k,total:0,E:0,D:0,L:0}));
 const by=Object.fromEntries(all.map(x=>[x.k,x]));
 state.faults.forEach(f=>(f.skills||[]).forEach(k=>{if(by[k]){by[k].total++;by[k][f.severity]++}}));
 host.innerHTML=all.map(x=>{const m=SKILL_META[x.k], cls=x.total===0?'empty-skill':x.total<=1?'low-skill':x.total<=3?'mid-skill':'high-skill';return `<article class="skill-card ${cls}"><div class="skill-title"><span>${m[0]}</span><b>${m[1]}</b><strong>${x.total}</strong></div><div class="skill-breakdown"><span>E ${x.E}</span><span>D ${x.D}</span><span>L ${x.L}</span></div></article>`}).join('');
}

function renderEventStatus(){const n=state.events.length;const e=state.events.filter(x=>x.type==='fault').length;const g=state.events.filter(x=>x.type==='gps_sample').length;$('#eventCount').textContent=`${n} esdeveniments`;$('#eventStatus').textContent=state.phase==='driving'?`Capturant context · ${e} incidències · ${g} mostres GPS`:state.phase==='finished'?`Sessió finalitzada · ${e} incidències · ${g} mostres GPS`:'Preparat per capturar context.'}
function renderCounters(){const e=state.faults.filter(f=>f.severity==='E').length,d=state.faults.filter(f=>f.severity==='D').length,l=state.faults.filter(f=>f.severity==='L').length;$('#countE').textContent=e;$('#countD').textContent=d;$('#countL').textContent=l;$('#navE').textContent=e;$('#navD').textContent=d;$('#navL').textContent=l;const no=e>=1||d>=2||(d>=1&&l>=5)||l>=10;const r=$('#result');r.textContent=no?'NO APTE provisional':'APTE provisional';r.className=no?'bad':'good';$('#resultDetail').textContent=`${state.faults.length} incidències · ${$('#student').value||'alumne sense nom'}`}
function formatDuration(sec){sec=Math.max(0,Math.floor(sec||0));return `${String(Math.floor(sec/60)).padStart(2,'0')}:${String(sec%60).padStart(2,'0')}`}
function loadSession(){try{const x=JSON.parse(localStorage.getItem('drivecoach-session')||'null');if(x){$('#student').value=x.student||'';$('#licence').value=x.licence||'B';state.faults=Array.isArray(x.faults)?x.faults:[];state.events=Array.isArray(x.events)?x.events:x.faults||[];state.sessionStarted=x.sessionStarted||null;state.examStarted=x.examStarted||null;state.examFinished=x.examFinished||null;state.phase=x.phase||'prep';state.durationMinutes=Number(x.durationMinutes)||25;state.minimumReached=Boolean(x.minimumReached);state.gpsTrack=Array.isArray(x.gpsTrack)?x.gpsTrack:[];state.lastPosition=x.lastPosition||null;state.voice=Object.assign(state.voice,x.voice||{});state.consent=Object.assign(state.consent,x.consent||{});$('#durationMinutes').value=String(state.durationMinutes);if(![...$('#durationMinutes').options].some(o=>o.value===String(state.durationMinutes))){$('#durationMinutes').value='custom';$('#customDuration').value=state.durationMinutes}}}catch{};if(state.phase==='driving'&&!state.examStarted)state.phase='prep';updatePhaseUI()}
function tick(){const now=Date.now();let sec=state.examStarted?Math.floor(((state.examFinished||now)-state.examStarted)/1000):0;$('#sessionClock').textContent=formatDuration(sec);const target=Math.max(1,Number(state.durationMinutes)||25)*60;const reached=state.phase==='driving'&&sec>=target;if(reached&&!state.minimumReached){state.minimumReached=true;save()}$('#phaseLabel').textContent=state.phase==='driving'?(reached?`Conducció · ${state.durationMinutes} min assolits`:'Conducció'):state.phase==='finished'?'Finalitzada':'Preparació';}
function updatePhaseUI(){const driving=state.phase==='driving',finished=state.phase==='finished';$('#startExam').disabled=driving||finished;$('#finishExam').disabled=!driving;$('#durationMinutes').disabled=driving||finished;$('#customDuration').disabled=driving||finished;$('#phaseLabel').textContent=driving?(state.minimumReached?`Conducció · ${state.durationMinutes} min assolits`:'Conducció'):finished?'Finalitzada':'Preparació';$('#status').textContent=finished?'Prova finalitzada':driving?'PROVA EN CURS':`DGT ${state.data?.source?.edition||'març 2026'}`;$('#picker').classList.toggle('hidden',!driving&&state.selectedSeverity===null)}
function getDurationMinutes(){let v=$('#durationMinutes').value;if(v==='custom'){const n=Number($('#customDuration').value);if(!Number.isFinite(n)||n<1||n>240){alert('Indica un temps personalitzat entre 1 i 240 minuts.');$('#customDuration').focus();return null}return Math.floor(n)}return Number(v)||25}
function setGpsUI(){const p=state.lastPosition;const status=$('#gpsStatus'),txt=$('#gpsText');if(p){txt.textContent=`GPS actiu · ±${Math.round(p.accuracy||0)} m`;$('#gpsLat').textContent=Number(p.lat).toFixed(6);$('#gpsLon').textContent=Number(p.lon).toFixed(6);$('#gpsAcc').textContent=`±${Math.round(p.accuracy||0)} m`;$('#gpsAccuracy').textContent=`Precisió ±${Math.round(p.accuracy||0)} m`;$('#gpsPoints').textContent=state.gpsTrack.length;status.classList.add('active');status.classList.remove('error')}else{txt.textContent=state.gpsError||'GPS esperant…';$('#gpsPoints').textContent=state.gpsTrack.length;status.classList.toggle('error',Boolean(state.gpsError));}}
function stopGps(){if(state.gpsWatchId!==null&&navigator.geolocation){navigator.geolocation.clearWatch(state.gpsWatchId);state.gpsWatchId=null}}
function addSessionEvent(type,data={}){const now=Date.now();const event={id:makeId(),type,time:now,relativeSec:state.examStarted?Math.max(0,Math.floor((now-state.examStarted)/1000)):0,position:state.lastPosition?{...state.lastPosition}:null,...data};state.events.push(event);save();return event}
function startGps(){state.gpsError=null;if(!('geolocation' in navigator)){state.gpsError='GPS no disponible';setGpsUI();return}setGpsUI();state.gpsWatchId=navigator.geolocation.watchPosition(pos=>{const point={lat:pos.coords.latitude,lon:pos.coords.longitude,accuracy:pos.coords.accuracy||null,speed:pos.coords.speed??null,heading:pos.coords.heading??null,altitude:pos.coords.altitude??null,timestamp:pos.timestamp,relativeSec:state.examStarted?Math.max(0,Math.floor((pos.timestamp-state.examStarted)/1000)):0};state.lastPosition=point;state.gpsTrack.push(point);if(state.gpsTrack.length>5000)state.gpsTrack.shift();if(state.examStarted&&(!state._lastGpsEventSec||point.relativeSec-state._lastGpsEventSec>=10)){state._lastGpsEventSec=point.relativeSec;state.events.push({id:makeId(),type:'gps_sample',time:pos.timestamp,relativeSec:point.relativeSec,position:{...point}})}setGpsUI();save()},err=>{const map={1:'Permís de localització denegat',2:'Posició GPS no disponible',3:'Temps d’espera del GPS esgotat'};state.gpsError=map[err.code]||'Error de GPS';setGpsUI()},{enableHighAccuracy:true,maximumAge:2000,timeout:10000})}
function consentAllows(kind){const c=state.consent||{};return c.student===$('#student').value.trim()&&c.name&&((kind==='video'&&c.video)||(kind==='audio'&&c.audio));}
function showConsent(){const panel=$('#consentPanel');if(!panel)return;$('#consentStudent').textContent=$('#student').value.trim()||'Alumne';$('#consentName').value=state.consent.student===$('#student').value.trim()?state.consent.name||'':'';$('#consentVideo').checked=state.consent.student===$('#student').value.trim()&&!!state.consent.video;$('#consentAudio').checked=state.consent.student===$('#student').value.trim()&&!!state.consent.audio;$('#consentStudentReport').checked=state.consent.student===$('#student').value.trim()&&!!state.consent.report;panel.classList.remove('hidden');panel.scrollIntoView({behavior:'smooth',block:'center'});}
function hideConsent(){$('#consentPanel')?.classList.add('hidden')}
function clearConsentSignature(){
 const c=$('#consentSignatureCanvas'); if(!c)return;
 const ctx=c.getContext('2d'); ctx.clearRect(0,0,c.width,c.height);
 $('#signatureEmpty')?.classList.remove('hidden');
 state.consent.signatureData='';
}
function setupConsentSignature(){
 const c=$('#consentSignatureCanvas'); if(!c||c.dataset.ready)return;
 c.dataset.ready='1';
 const ctx=c.getContext('2d'); let drawing=false, has=false;
 const pos=e=>{const r=c.getBoundingClientRect(); const t=e.touches?.[0]; return {x:((t?t.clientX:e.clientX)-r.left)*(c.width/r.width),y:((t?t.clientY:e.clientY)-r.top)*(c.height/r.height)}};
 const start=e=>{e.preventDefault();drawing=true;has=true;const p=pos(e);ctx.beginPath();ctx.moveTo(p.x,p.y);$('#signatureEmpty')?.classList.add('hidden');};
 const move=e=>{if(!drawing)return;e.preventDefault();const p=pos(e);ctx.lineTo(p.x,p.y);ctx.stroke();};
 const stop=e=>{if(!drawing)return;e.preventDefault();drawing=false;state.consent.signatureData=c.toDataURL('image/png');};
 ctx.lineWidth=2.5;ctx.lineCap='round';ctx.lineJoin='round';
 c.addEventListener('pointerdown',start);c.addEventListener('pointermove',move);c.addEventListener('pointerup',stop);c.addEventListener('pointercancel',stop);c.addEventListener('pointerleave',stop);
 $('#clearSignature')?.addEventListener('click',clearConsentSignature);
}
function showConsent(){
 const panel=$('#consentPanel');if(!panel)return;
 $('#consentStudent').textContent=$('#student').value.trim()||'Alumne';
 const same=state.consent.student===$('#student').value.trim();
 $('#consentName').value=same?state.consent.name||'':'';
 $('#consentVideo').checked=same&&!!state.consent.video;
 $('#consentAudio').checked=same&&!!state.consent.audio;
 $('#consentStudentReport').checked=same&&!!state.consent.report;
 setupConsentSignature();
 clearConsentSignature();
 if(same&&state.consent.signatureData){const c=$('#consentSignatureCanvas'),ctx=c.getContext('2d'),img=new Image();img.onload=()=>{ctx.drawImage(img,0,0,c.width,c.height);$('#signatureEmpty')?.classList.add('hidden')};img.src=state.consent.signatureData;}
 panel.classList.remove('hidden');panel.scrollIntoView({behavior:'smooth',block:'center'});
}
function hideConsent(){$('#consentPanel')?.classList.add('hidden')}
function saveConsent(){
 const name=$('#consentName').value.trim(),video=$('#consentVideo').checked,audio=$('#consentAudio').checked,report=$('#consentStudentReport').checked;
 const canvas=$('#consentSignatureCanvas'),signature=canvas?canvas.toDataURL('image/png'):'';
 if(!name){alert('Indica el nom i cognoms de l’alumne per registrar l’autorització.');$('#consentName').focus();return false}
 if(!video&&!audio){alert('Selecciona com a mínim vídeo o àudio.');return false}
 if(!signature || signature.length<200){alert('L’alumne ha de signar a la pantalla abans d’autoritzar la gravació.');return false}
 state.consent={student:$('#student').value.trim(),video,audio,report,name,signatureData:signature,timestamp:new Date().toISOString(),version:2,method:'firma-manuscrita-pantalla'};
 save();hideConsent();return true
}
function consentSummary(){const c=state.consent;return c&&c.student?{student:c.student,video:!!c.video,audio:!!c.audio,report:!!c.report,name:c.name,timestamp:c.timestamp,version:c.version}:null}
function mediaSupported(){return !!(navigator.mediaDevices&&navigator.mediaDevices.getUserMedia&&window.MediaRecorder)}
function mediaMime(){const types=['video/webm;codecs=vp9,opus','video/webm;codecs=vp8,opus','video/webm'];return types.find(t=>MediaRecorder.isTypeSupported(t))||''}
function setMediaStatus(t){$('#mediaStatus').textContent=t}
function addMediaEvent(type,data={}){return addSessionEvent(type,{...data,mediaTime:state.media.startedAt?Math.max(0,Math.floor((Date.now()-state.media.startedAt)/1000)):0})}
async function startMedia(){
 if(state.phase!=='driving'){alert('Inicia la prova abans d’iniciar l’enregistrament.');return}
 if(!mediaSupported()){alert('Aquest navegador no permet enregistrament multimèdia. Prova Chrome/Edge/Safari actual.');return}
 if(state.media.active)return;
 const currentStudent=$('#student').value.trim();
 if(!state.consent || state.consent.student!==currentStudent || (!state.consent.video&&!state.consent.audio)){showConsent();return}
 const wantVideo=!!state.consent.video,wantAudio=!!state.consent.audio;
 if(!wantVideo&&!wantAudio)return;
 state.media={active:true,streams:[],recorders:[],chunks:{interior:[],exterior:[]},blobs:{interior:null,exterior:null},startedAt:Date.now(),stoppedAt:null};
 const mime=mediaMime();
 // Interior: càmera frontal + àudio. Exterior: càmera posterior sense àudio.
 try{
   const interior=await navigator.mediaDevices.getUserMedia({audio:wantAudio,video:wantVideo?{facingMode:{ideal:'user'},width:{ideal:1280},height:{ideal:720}}:false});
   state.media.streams.push(interior); $('#videoInterior').srcObject=interior; $('#interiorStatus').textContent=wantVideo?(wantAudio?'Activa · àudio + vídeo':'Activa · vídeo'): 'Activa · només àudio';
   const r=new MediaRecorder(interior,mime?{mimeType:mime}:undefined); state.media.recorders.push({key:'interior',recorder:r});
   r.ondataavailable=e=>{if(e.data.size)state.media.chunks.interior.push(e.data)}; r.onstop=()=>{state.media.blobs.interior=new Blob(state.media.chunks.interior,{type:r.mimeType||'video/webm'});updateMediaButtons()}; r.start(1000);
 }catch(e){state.media.active=false;state.media.streams=[];setMediaStatus('No s’ha pogut iniciar');$('#interiorStatus').textContent='No disponible';alert('No s’ha pogut accedir a la càmera/micròfon interior. Revisa els permisos.');return}
 try{
   if(!wantVideo){throw new Error('video_not_authorized')}
   const exterior=await navigator.mediaDevices.getUserMedia({audio:false,video:{facingMode:{ideal:'environment'},width:{ideal:1280},height:{ideal:720}}});
   state.media.streams.push(exterior); $('#videoExterior').srcObject=exterior; $('#exteriorStatus').textContent='Activa · vídeo';
   const r=new MediaRecorder(exterior,mime?{mimeType:mime}:undefined); state.media.recorders.push({key:'exterior',recorder:r});
   r.ondataavailable=e=>{if(e.data.size)state.media.chunks.exterior.push(e.data)}; r.onstop=()=>{state.media.blobs.exterior=new Blob(state.media.chunks.exterior,{type:r.mimeType||'video/webm'});updateMediaButtons()}; r.start(1000);
 }catch(e){$('#exteriorStatus').textContent='No disponible · el dispositiu pot no admetre dues càmeres';}
 state.media.active=true; setMediaStatus(state.media.recorders.length===2?'2 càmeres actives':'1 càmera activa'); addMediaEvent('media_start',{cameras:state.media.recorders.map(x=>x.key),audio:state.media.recorders.some(x=>x.key==='interior')}); updateMediaButtons(); save();
}
function stopMedia(){if(!state.media.active)return;state.media.stoppedAt=Date.now();state.media.recorders.forEach(x=>{try{if(x.recorder.state!=='inactive')x.recorder.stop()}catch{}});state.media.streams.forEach(s=>s.getTracks().forEach(t=>t.stop()));$('#videoInterior').srcObject=null;$('#videoExterior').srcObject=null;state.media.active=false;setMediaStatus('Finalitzant…');addMediaEvent('media_stop',{durationSec:state.media.startedAt?Math.floor((state.media.stoppedAt-state.media.startedAt)/1000):0});updateMediaButtons();save();setTimeout(()=>{setMediaStatus('Enregistrament disponible');updateMediaButtons()},400)}
function updateMediaButtons(){const active=state.media.active;$('#startMedia').disabled=active||state.phase!=='driving';$('#stopMedia').disabled=!active;$('#downloadMedia').disabled=!state.media.blobs.interior&&!state.media.blobs.exterior}
function downloadBlob(blob,name){if(!blob)return;const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),2000)}
function downloadMedia(){const base=`DriveCoach_${($('#student').value.trim()||'alumne').replace(/[^a-z0-9à-ÿ_-]+/gi,'_')}_${new Date().toISOString().slice(0,10)}`;if(state.media.blobs.interior)downloadBlob(state.media.blobs.interior,`${base}_interior.webm`);if(state.media.blobs.exterior)downloadBlob(state.media.blobs.exterior,`${base}_exterior.webm`)}

function generateLocalAnalysis(){
 const host=$('#aiResults'), status=$('#aiStatus');
 if(!state.faults.length){host.classList.add('hidden');status.textContent='L’anàlisi estarà disponible quan hi hagi incidències.';return}
 const byCode={}; state.faults.forEach(f=>{const k=f.code+'|'+f.text;(byCode[k]??=[]).push(f)});
 const repeated=Object.entries(byCode).filter(([,a])=>a.length>=2).sort((a,b)=>b[1].length-a[1].length);
 const counts={E:0,D:0,L:0};state.faults.forEach(f=>counts[f.severity]++);
 const blocks={};state.faults.forEach(f=>{blocks[f.section]=(blocks[f.section]||0)+1});
 const topBlocks=Object.entries(blocks).sort((a,b)=>b[1]-a[1]).slice(0,3);
 const rec=[];
 if(counts.E) rec.push('Revisar immediatament les incidències eliminatòries i treballar-ne el patró abans de la següent prova.');
 if(counts.D>=2) rec.push('Hi ha dues o més deficients: convé prioritzar-les abans d’afegir nous objectius.');
 if(counts.D>=1&&counts.L>=5) rec.push('El patró actual arriba al llindar D + 5 L del barem; prioritzar la reducció de lleus relacionades.');
 if(counts.L>=5&&!counts.D) rec.push('Hi ha acumulació de lleus; buscar si provenen d’un mateix hàbit de conducció.');
 if(repeated.length) rec.push('Hi ha incidències repetides: poden indicar un hàbit que necessita treball específic.');
 if(!rec.length) rec.push('La sessió no mostra un patró crític segons el barem configurat. Continuar observant l’evolució.');
 const no=counts.E>=1||counts.D>=2||(counts.D>=1&&counts.L>=5)||counts.L>=10;
 host.innerHTML=`<div class="ai-card"><h3>Resum</h3><div class="ai-tags"><span class="ai-tag">E: ${counts.E}</span><span class="ai-tag">D: ${counts.D}</span><span class="ai-tag">L: ${counts.L}</span><span class="ai-tag">Incidències: ${state.faults.length}</span></div><p>Resultat segons el barem: <b>${no?'NO APTE provisional':'APTE provisional'}</b>.</p></div>`+
 `<div class="ai-card"><h3>Patrons detectats</h3>${repeated.length?repeated.slice(0,5).map(([k,a])=>{const [code,text]=k.split('|');return `<p><b>${escapeHtml(code)}</b> · ${escapeHtml(text)} <strong>×${a.length}</strong></p>`}).join(''):'<p>No s’han detectat repeticions exactes dins aquesta sessió.</p>'}</div>`+
 `<div class="ai-card"><h3>Àrees amb més incidències</h3>${topBlocks.length?topBlocks.map(([b,n])=>`<p><b>${escapeHtml(b||'Sense bloc')}</b>: ${n}</p>`).join(''):'<p>—</p>'}</div>`+
 `<div class="ai-card"><h3>Recomanacions</h3>${rec.map(x=>`<p>• ${escapeHtml(x)}</p>`).join('')}</div>`;
 host.classList.remove('hidden');status.textContent='Anàlisi local generada a partir de les incidències de la sessió.';
 state.events.push({id:makeId(),type:'ai_analysis',time:Date.now(),relativeSec:state.examStarted?Math.floor((Date.now()-state.examStarted)/1000):0,summary:{counts,repeated:repeated.map(([k,a])=>({key:k,count:a.length})),topBlocks,recommendations:rec}});save();
}


function latestFault(){return state.faults.length?state.faults[state.faults.length-1]:null}

function drivingContext(f=latestFault()){
 const now=Date.now(), started=state.examStarted||state.sessionStarted;
 const rel=started?Math.max(0,Math.floor((now-started)/1000)):0;
 const recent=state.faults.slice(-5);
 const same=f?recent.filter(x=>x.code===f.code).length:0;
 const skillCounts={};
 recent.forEach(x=>(x.skills||[]).forEach(k=>skillCounts[k]=(skillCounts[k]||0)+1));
 const dominant=Object.entries(skillCounts).sort((a,b)=>b[1]-a[1])[0];
 const phase=state.phase==='driving'?'Conducció':state.phase==='finished'?'Finalitzada':'Preparació';
 const target=Number(state.durationMinutes)||25;
 const timeRatio=target?rel/(target*60):0;
 const timeState=timeRatio>=1?'temps objectiu superat':timeRatio>=.8?'tram final':timeRatio>=.5?'tram mitjà':'inici';
 const priority=f?(f.severity==='E'||f.severity==='D'||same>=2):false;
 const pattern=same>=2||!!(f&&state.faults.filter(x=>x.code===f.code).length>=3);
 return {phase,rel,target,timeState,gps:state.lastPosition?{lat:state.lastPosition.lat,lon:state.lastPosition.lon,accuracy:state.lastPosition.accuracy}:null,
   fault:f?{id:f.id,severity:f.severity,code:f.code,title:f.title,skills:f.skills||[],relativeSec:f.relativeSec}:null,
   sameRecent:same,pattern,dominantSkill:dominant?{key:dominant[0],count:dominant[1]}:null,priority};
}
function contextRecommendation(ctx=drivingContext()){
 if(!ctx.fault)return {title:'Esperant incidència',text:'Cap incidència recent. L’assistent només intervindrà segons la configuració del professor.',key:'idle'};
 const names=(ctx.fault.skills||[]).map(k=>SKILL_META[k]?.[1]).filter(Boolean);
 if(ctx.fault.severity==='E')return {title:'⚠️ Prioritat de seguretat',text:names.length?`Incidència eliminatòria vinculada a ${names[0]}. Prioritza seguretat i correcció immediata.`:'Incidència eliminatòria. Prioritza seguretat i correcció immediata.',key:'priority'};
 if(ctx.pattern)return {title:'🔁 Patró repetit',text:`${ctx.fault.code} apareix ${ctx.sameRecent} vegades en les últimes ${Math.min(5,state.faults.length)} incidències. Treballa el procés, no només la solució.`,key:'pattern'};
 if(ctx.fault.severity==='D')return {title:'🟠 Correcció prioritària',text:names.length?`Centra la intervenció en ${names[0]} i dona una instrucció breu.`:'Dona una instrucció breu i centrada en el risc.',key:'priority'};
 if(names.length)return {title:'🟢 Feedback contextual',text:`Incidència relacionada amb ${names[0]}. Observa primer el context i intervé només si aporta valor.`,key:'normal'};
 return {title:'🟢 Feedback contextual',text:'Observa el context abans d’intervenir.',key:'normal'};
}
function renderDrivingContext(){
 const c=drivingContext(), r=contextRecommendation(c);
 const set=(id,v)=>{const el=document.getElementById(id);if(el)el.textContent=v};
 set('ctxPhase',c.phase); set('ctxTime',formatDuration(c.rel));
 set('ctxGps',c.gps?`±${Math.round(c.gps.accuracy||0)} m`:'No disponible');
 set('ctxFault',c.fault?`${c.fault.severity} · ${c.fault.code}`:'—');
 set('ctxSkill',c.fault&&c.fault.skills?.length?SKILL_META[c.fault.skills[0]]?.[1]||'—':'—');
 set('ctxPattern',c.pattern?'Detectat':'No');
 const mode=document.getElementById('contextModeStatus'); if(mode)mode.textContent=window.DriveCoachRealtime?.active?'ACTIU':'LOCAL';
 const card=document.getElementById('realtimeCard'),title=document.getElementById('realtimeTitle'),text=document.getElementById('realtimeText');
 if(card&&title&&text&&window.DriveCoachRealtime?.active){
   const cfg=window.DriveCoachRealtime.config||{};
   const allowed=cfg.level==='full'||(cfg.level==='patterns'&&r.key!=='normal')||(cfg.level==='priority'&&r.key==='priority');
   title.textContent=allowed?r.title:'Context capturat';
   text.textContent=allowed?r.text:'Context analitzat; no cal intervenir segons el nivell seleccionat.';
   card.className='assistant-card '+(r.key==='priority'?'critical':r.key==='pattern'?'warning':'normal');
 } else if(card&&title&&text){
   title.textContent='Assistent desactivat';
   text.textContent='El context es continua registrant, però no hi ha intervenció automàtica.';
   card.className='assistant-card';
 }
}
function assistantRecommendation(){
 const f=latestFault();
 const host=$('#assistantCard'), title=$('#assistantTitle'), text=$('#assistantText'), meta=$('#assistantMeta');
 if(!host||!title||!text||!meta)return;
 if(!f){
   host.className='assistant-card'; title.textContent='Preparat';
   text.textContent='Quan registris una incidència, DriveCoach mostrarà una indicació pedagògica breu basada en el context de la sessió.';
   meta.textContent='Sense incidències registrades'; return;
 }
 const names=(f.skills||[]).map(k=>SKILL_META[k]?.[1]).filter(Boolean);
 let t='Observa el context i demana a l’alumne que expliqui què ha vist i què ha decidit.';
 if((f.skills||[]).includes('OBS')) t='Abans d’actuar: mirar, interpretar i confirmar. Demana a l’alumne què ha detectat abans de corregir.';
 else if((f.skills||[]).includes('SIG')) t='Recorda la seqüència: decidir → senyalitzar → comprovar → executar.';
 else if((f.skills||[]).includes('CAN')) t='Treballa la seqüència observació → senyalització → comprovació → desplaçament.';
 else if((f.skills||[]).includes('DIS')) t='Fes verbalitzar la distància de seguretat adequada i el marge disponible.';
 else if((f.skills||[]).includes('MAN')) t='Prioritza control suau i estable del vehicle; evita acumular instruccions alhora.';
 else if((f.skills||[]).includes('PAR')) t='Divideix la maniobra en passos curts i deixa que l’alumne anticipi el següent moviment.';
 else if((f.skills||[]).includes('DEC')) t='Pregunta “què has vist?” i “què faries ara?” per treballar anticipació i presa de decisions.';
 else if((f.skills||[]).includes('SEG')) t='Prioritza eliminar el risc abans d’analitzar el detall tècnic de la incidència.';
 const recent=state.faults.slice(-5), same=recent.filter(x=>x.code===f.code).length;
 if(same>=2)t+=' Aquest patró ja apareix diverses vegades en la sessió: evita donar només la solució i treballa el procés.';
 title.textContent=(f.severity==='E'?'⚠️ Prioritat de seguretat':f.severity==='D'?'🟠 Correcció prioritària':'🟢 Feedback pedagògic');
 text.textContent=t;
 meta.textContent=`Última incidència: ${f.code} · ${f.severity} · ${names.join(', ')||'competència no assignada'} · ${same} vegada/es en les últimes ${recent.length}`;
 host.className='assistant-card '+(f.severity==='E'?'critical':f.severity==='D'?'warning':'normal');
}

function voiceSupported(){return 'speechSynthesis' in window && 'SpeechSynthesisUtterance' in window}
function stopVoice(){if(voiceSupported())window.speechSynthesis.cancel();$('#voiceStatus')&&( $('#voiceStatus').textContent='Veu aturada')}
function speak(text,key='general',force=false){
 if(!voiceSupported()||!state.voice.enabled)return false;
 const now=Date.now();
 if(!force && now-state.voice.lastAt<state.voice.cooldownSec*1000)return false;
 if(!force && state.voice.lastKey===key)return false;
 const u=new SpeechSynthesisUtterance(text);u.lang=state.voice.language==='ca'?'ca-ES':'es-ES';u.rate=1.03;u.pitch=1;u.volume=.9;
 const voices=window.speechSynthesis.getVoices();const pref=state.voice.language==='ca'?/^ca(-|_)/i:/^es(-|_)/i; const v=voices.find(x=>pref.test(x.lang))||voices.find(x=>/^(es|ca)(-|_)/i.test(x.lang));if(v)u.voice=v;
 u.onstart=()=>{const x=$('#voiceStatus');if(x)x.textContent='🔊 Parlant…'};u.onend=()=>{const x=$('#voiceStatus');if(x)x.textContent=state.voice.enabled?'Veu activa':'Veu desactivada'};
 window.speechSynthesis.cancel();window.speechSynthesis.speak(u);state.voice.lastAt=now;state.voice.lastKey=key;return true;
}
function voiceTextForFault(f){
 const skills=f.skills||[],ca=state.voice.language==='ca';
 if(f.severity==='E')return ca?(skills.includes('OBS')?'Atenció. Prioritat de seguretat: observa abans d’actuar.':'Atenció. Prioritat de seguretat.'):(skills.includes('OBS')?'Atención. Prioridad de seguridad: observa antes de actuar.':'Atención. Prioridad de seguridad.');
 if(state.voice.verbosity==='minimal')return ca?(skills.includes('OBS')?'Observació.':skills.includes('SIG')?'Senyalització.':skills.includes('CAN')?'Canvi de direcció.':'Revisa aquesta incidència.'):(skills.includes('OBS')?'Observación.':skills.includes('SIG')?'Señalización.':skills.includes('CAN')?'Cambio de dirección.':'Revisa esta incidencia.');
 if(skills.includes('OBS'))return ca?'Observació. Mira, interpreta i confirma abans d’actuar.':'Observación. Mira, interpreta y confirma antes de actuar.';
 if(skills.includes('SIG'))return ca?'Senyalització. Decideix, senyalitza, comprova i executa.':'Señalización. Decide, señaliza, comprueba y ejecuta.';
 if(skills.includes('CAN'))return ca?'Canvi de direcció. Observa, senyalitza, comprova i desplaça’t.':'Cambio de dirección. Observa, señaliza, comprueba y desplázate.';
 if(skills.includes('DIS'))return ca?'Distància. Mantén un marge de seguretat suficient.':'Distancia. Mantén un margen de seguridad suficiente.';
 if(skills.includes('MAN'))return ca?'Maneig. Control suau i estable del vehicle.':'Manejo. Control suave y estable del vehículo.';
 if(skills.includes('PAR'))return ca?'Maniobra. Divideix-la en passos i anticipa el següent moviment.':'Maniobra. Divídela en pasos y anticipa el siguiente movimiento.';
 if(skills.includes('DEC'))return ca?'Decisió. Mira amb temps i anticipa abans d’actuar.':'Decisión. Mira con tiempo y anticipa antes de actuar.';
 return ca?'Revisa el context i prioritza la seguretat.':'Revisa el contexto y prioriza la seguridad.';
}
function voiceAfterFault(f){
 if(!state.voice.auto||!state.voice.enabled)return;
 const rt=window.DriveCoachRealtime;
 const ctx=drivingContext(f), rec=contextRecommendation(ctx);
 if(rt && rt.config){
   const level=rt.config.level||'priority';
   const allowed=rt.active && (level==='full'||(level==='patterns'&&rec.key!=='normal')||(level==='priority'&&rec.key==='priority'));
   if(!allowed)return;
 }
 const recent=state.faults.slice(-5),same=recent.filter(x=>x.code===f.code).length;
 let text=voiceTextForFault(f);if(same>=2&&state.voice.verbosity!=='minimal')text+=state.voice.language==='ca'?' Patró repetit.':' Patrón repetido.';
 speak(text,f.code+'|'+f.severity+'|'+(f.skills||[]).join(',')+'|'+state.voice.language);
}

function renderVoiceControls(){
 const toggle=$('#voiceEnabled'),auto=$('#voiceAuto'),verb=$('#voiceVerbosity'),lang=$('#voiceLanguage'),status=$('#voiceStatus');
 if(toggle)toggle.checked=state.voice.enabled;if(auto)auto.checked=state.voice.auto;if(verb)verb.value=state.voice.verbosity;if(lang)lang.value=state.voice.language||'es';if(status)status.textContent=voiceSupported()?(state.voice.enabled?'Veu activa':'Veu desactivada'):'Veu no compatible amb aquest navegador';
}
function startExam(){if(!$('#student').value.trim()){alert('Escriu el nom de l’alumne abans d’iniciar la prova.');$('#student').focus();return}const duration=getDurationMinutes();if(duration===null)return;state.durationMinutes=duration;state.minimumReached=false;state.examStarted=Date.now();state.examFinished=null;state.sessionStarted=state.examStarted;state.phase='driving';state.faults=[];state.events=[];state.selectedSeverity=null;state.gpsTrack=[];state.lastPosition=null;save();addSessionEvent('session_start',{durationTargetMinutes:state.durationMinutes});startGps();renderFaults();renderCounters();updatePhaseUI();tick()}
function finishExam(){if(state.phase!=='driving')return;const hadMedia=state.media.active;if(hadMedia)stopMedia();state.examFinished=Date.now();stopGps();state.phase='finished';addSessionEvent('session_finish',{durationSec:Math.floor((state.examFinished-state.examStarted)/1000)});save();updatePhaseUI();renderSummary();renderEventStatus();$('#sessionSummary').scrollIntoView({behavior:'smooth',block:'start'});if(hadMedia)setTimeout(()=>{renderStudentReportMedia();},700);}
function renderSkillMapInto(host){
 if(!host)return; const keys=Object.keys(SKILL_META); const counts=Object.fromEntries(keys.map(k=>[k,0]));
 state.faults.forEach(f=>(f.skills||[]).forEach(k=>{if(k in counts)counts[k]++}));
 host.innerHTML=keys.map(k=>{const m=SKILL_META[k];return `<span class="summary-skill"><b>${m[0]} ${m[1]}</b><em>${counts[k]}</em></span>`}).join('');
}

function renderSummary(){const e=state.faults.filter(f=>f.severity==='E').length,d=state.faults.filter(f=>f.severity==='D').length,l=state.faults.filter(f=>f.severity==='L').length;const no=e>=1||d>=2||(d>=1&&l>=5)||l>=10;const s=$('#sessionSummary');s.classList.remove('hidden');s.innerHTML=`<div class="summary-card"><h2>Resultat de la prova</h2><div class="summary-result ${no?'bad':'good'}">${no?'NO APTE':'APTE'}</div><p><b>${escapeHtml($('#student').value||'Alumne')}</b> · Permís ${escapeHtml($('#licence').value)}</p><div class="summary-grid"><span>E <b>${e}</b></span><span>D <b>${d}</b></span><span>L <b>${l}</b></span><span>Temps <b>${formatDuration(state.examStarted&&state.examFinished?(state.examFinished-state.examStarted)/1000:0)}</b></span></div><div id="summarySkillMap" class="summary-skill-grid"></div><div class="summary-actions"><button id="summaryReport" class="primary">📘 Veure informe de l’alumne</button><button id="summaryExport" class="secondary">⬇ Exportar dades</button></div></div>`;$('#summaryExport').onclick=exportReport;$('#summaryReport').onclick=openStudentReport; renderSkillMapInto($('#summarySkillMap'));renderStudentReportMedia();}
function renderStudentReportMedia(){
 const section=$('#studentReport'),host=$('#fullSessionMedia');
 if(!section||!host)return;
 const hasI=!!state.media.blobs.interior&&!!state.consent.video,hasE=!!state.media.blobs.exterior&&!!state.consent.video;
 if(!hasI&&!hasE){section.classList.add('hidden');return}
 section.classList.remove('hidden');
 $('#studentReportMediaStatus').textContent=hasI&&hasE?'Vídeo interior + exterior disponibles':hasI?'Vídeo interior + àudio disponibles':'Vídeo exterior disponible';
 host.innerHTML='';
 if(hasI){
   const card=document.createElement('article');card.className='full-media-card';
   const url=URL.createObjectURL(state.media.blobs.interior);
   card.innerHTML='<h3>📷 Sessió completa · interior + àudio</h3><video id="fullInteriorVideo" controls playsinline preload="metadata"></video><small>Enregistrament complet de la sessió. L’àudio forma part de la gravació interior.</small>';
   host.appendChild(card);const v=card.querySelector('video');v.src=url;v.dataset.url=url;
 }
 if(hasE){
   const card=document.createElement('article');card.className='full-media-card';
   const url=URL.createObjectURL(state.media.blobs.exterior);
   card.innerHTML='<h3>📷 Sessió completa · exterior</h3><video id="fullExteriorVideo" controls playsinline preload="metadata"></video><small>Enregistrament complet de la sessió exterior.</small>';
   host.appendChild(card);const v=card.querySelector('video');v.src=url;v.dataset.url=url;
 }
 const bi=$('#downloadFullInterior'),be=$('#downloadFullExterior');
 if(bi){bi.disabled=!hasI;bi.onclick=()=>hasI&&downloadBlob(state.media.blobs.interior,`DriveCoach_${($('#student').value.trim()||'alumne').replace(/[^a-z0-9à-ÿ_-]+/gi,'_')}_sessio_completa_interior_audio.webm`)}
 if(be){be.disabled=!hasE;be.onclick=()=>hasE&&downloadBlob(state.media.blobs.exterior,`DriveCoach_${($('#student').value.trim()||'alumne').replace(/[^a-z0-9à-ÿ_-]+/gi,'_')}_sessio_completa_exterior.webm`)}
 const bd=$('#studentReportData');if(bd)bd.onclick=exportReport;
}

function openStudentReport(){renderStudentReportMedia();const section=$('#studentReport');if(section&&!section.classList.contains('hidden'))section.scrollIntoView({behavior:'smooth',block:'start'});}

function exportReport(){const payload={app:'DriveCoach',dgtEdition:state.data.source.edition,student:$('#student').value.trim(),licence:$('#licence').value,startedAt:state.examStarted?new Date(state.examStarted).toISOString():null,finishedAt:state.examFinished?new Date(state.examFinished).toISOString():null,durationSec:state.examStarted&&state.examFinished?Math.floor((state.examFinished-state.examStarted)/1000):null,result:$('#result').classList.contains('bad')?'NO APTE':'APTE',counts:{E:state.faults.filter(f=>f.severity==='E').length,D:state.faults.filter(f=>f.severity==='D').length,L:state.faults.filter(f=>f.severity==='L').length},faults:state.faults,events:state.events,gps:{points:state.gpsTrack.length,track:state.gpsTrack,lastPosition:state.lastPosition},media:{recorded:Boolean(state.media.blobs.interior||state.media.blobs.exterior),interior:Boolean(state.media.blobs.interior),exterior:Boolean(state.media.blobs.exterior),startedAt:state.media.startedAt,stoppedAt:state.media.stoppedAt},consent:consentSummary()};const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`DriveCoach_${($('#student').value.trim()||'alumne').replace(/[^a-z0-9à-ÿ_-]+/gi,'_')}_${new Date().toISOString().slice(0,10)}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
function newSession(){if(confirm('Començar una nova sessió? S’esborraran les incidències actuals.')){state.faults=[];state.events=[];state.sessionStarted=null;state.examStarted=null;state.examFinished=null;state.phase='prep';state.selectedSeverity=null;state.durationMinutes=25;state.minimumReached=false;state.gpsTrack=[];state.lastPosition=null;state.gpsError=null;state._lastGpsEventSec=null;stopGps();if(state.media.active)stopMedia();state.media={active:false,streams:[],recorders:[],chunks:{interior:[],exterior:[]},blobs:{interior:null,exterior:null},clips:{},startedAt:null,stoppedAt:null};state.consent={student:'',video:false,audio:false,report:false,name:'',timestamp:null,version:1};hideConsent();updateMediaButtons();$('#durationMinutes').value='25';$('#customDuration').value='';$('#customDuration').classList.add('hidden');save();$('#sessionSummary').classList.add('hidden');renderFaults();renderCounters();renderEventStatus();renderEvidence();assistantRecommendation();updatePhaseUI();tick()}}
$$('[data-sev]').forEach(b=>b.onclick=()=>openPicker(b.dataset.sev));$('#closePicker').onclick=()=>{$('#picker').classList.add('hidden');state.selectedSeverity=null};$('#search').oninput=render;$('#sectionFilter').onchange=render;$('#student').oninput=()=>{if(state.consent.student!==$('#student').value.trim()){state.consent={student:'',video:false,audio:false,report:false,name:'',timestamp:null,version:1};}save();renderCounters()};$('#licence').onchange=save;$('#durationMinutes').onchange=()=>{const custom=$('#durationMinutes').value==='custom';$('#customDuration').classList.toggle('hidden',!custom);if(!custom){state.durationMinutes=Number($('#durationMinutes').value)||25;save()}else{$('#customDuration').focus()}};$('#customDuration').oninput=()=>{const n=Number($('#customDuration').value);if(Number.isFinite(n)&&n>=1&&n<=240){state.durationMinutes=Math.floor(n);save()}};$('#scrollFaults').onclick=()=>$('.session-section').scrollIntoView({behavior:'smooth'});$('#undo').onclick=()=>{state.faults.pop();save();renderFaults();renderCounters()};$('#newSession').onclick=newSession;$('#startExam').onclick=startExam;$('#finishExam').onclick=()=>finishExam();$('#exportReport').onclick=exportReport;$('#startMedia').onclick=startMedia;$('#saveConsent').onclick=()=>{if(saveConsent())startMedia()};$('#cancelConsent').onclick=hideConsent;$('#stopMedia').onclick=stopMedia;$('#downloadMedia').onclick=downloadMedia;$('#timelinePlayLast').onclick=()=>{const f=latestFault();if(f){renderEvidence(f);$('#evidenceViewer')?.classList.remove('hidden')}};$('#timelineExport').onclick=exportMediaTimeline;$('#closeEvidence').onclick=closeEvidence;$('#runAnalysis').onclick=generateLocalAnalysis;$('#v19Analyze').onclick=runV19;$('#v20Export').onclick=exportV20Package;$('#v20Copy').onclick=copyV20Package;$('#v19Export').onclick=exportV19;$('#assistantRefresh').onclick=assistantRecommendation;$('#voiceEnabled').onchange=()=>{state.voice.enabled=$('#voiceEnabled').checked;save();renderVoiceControls();if(!state.voice.enabled)stopVoice()};$('#voiceAuto').onchange=()=>{state.voice.auto=$('#voiceAuto').checked;save();renderVoiceControls()};$('#voiceVerbosity').onchange=()=>{state.voice.verbosity=$('#voiceVerbosity').value;save()};$('#voiceLanguage').onchange=()=>{state.voice.language=$('#voiceLanguage').value;save();renderVoiceControls()};$('#voiceTest').onclick=()=>speak(state.voice.language==='ca'?'DriveCoach. Assistent de veu activat.':'DriveCoach. Asistente de voz activado.','test',true);$('#voiceStop').onclick=stopVoice;$('#assistantClear').onclick=()=>{const h=$('#assistantCard');if(h){h.className='assistant-card';$('#assistantTitle').textContent='Preparat';$('#assistantText').textContent='Recomanació netejada. El professor continua tenint el control.';$('#assistantMeta').textContent='Netejat manualment'}};

function mediaTimelineItems(){
  return state.faults.slice().sort((a,b)=>a.relativeSec-b.relativeSec);
}
function renderMediaTimeline(){
  const host=$('#mediaTimeline'), count=$('#mediaTimelineCount');
  if(!host||!count)return;
  const items=mediaTimelineItems(); count.textContent=`${items.length} ${items.length===1?'marca':'marques'}`;
  if(!items.length){host.className='media-timeline-empty';host.textContent='Inicia una sessió i registra incidències per crear la cronologia.';return}
  host.className='media-timeline';
  const total=Math.max(1, state.examFinished&&state.examStarted?Math.floor((state.examFinished-state.examStarted)/1000):(state.examStarted?Math.floor((Date.now()-state.examStarted)/1000):1));
  host.innerHTML=items.map((f,i)=>{
    const start=Math.max(0,f.evidenceWindow?.startSec??Math.max(0,f.relativeSec-10));
    const end=Math.min(total, f.evidenceWindow?.endSec??f.relativeSec+10);
    const left=Math.max(0,Math.min(100,(start/total)*100));
    const width=Math.max(1,Math.min(100-left,((end-start)/total)*100));
    const marker=Math.max(0,Math.min(100,(f.relativeSec/total)*100));
    const sev=f.severity==='E'?'critical':f.severity==='D'?'warning':'normal';
    return `<div class="timeline-item">
      <div class="timeline-time">${escapeHtml(formatDuration(f.relativeSec))}</div>
      <div><div><b>${escapeHtml(f.code)}</b> · ${escapeHtml(severityText(f.severity))}</div>
        <div class="timeline-bar" title="Finestra ${formatDuration(start)}–${formatDuration(end)}">
          <span class="timeline-window ${sev}" style="margin-left:${left}%;width:${width}%"></span>
          <span class="timeline-marker" style="left:${marker}%"></span>
        </div>
        <small>${escapeHtml((f.skills||[]).map(k=>SKILL_META[k]?.[1]).filter(Boolean).join(' · ')||'Sense competència')}</small>
      </div>
      <button class="secondary timeline-open" data-id="${escapeHtml(f.id)}">▶ Evidència</button>
    </div>`;
  }).join('');
  $$('.timeline-open').forEach(btn=>btn.onclick=()=>{const f=state.faults.find(x=>x.id===btn.dataset.id);if(f){renderEvidence(f);$('#evidenceViewer')?.classList.remove('hidden')}});
}
function exportMediaTimeline(){
  const payload={app:'DriveCoach',version:'V18',student:$('#student')?.value.trim()||'',createdAt:new Date().toISOString(),
    recording:{startedAt:state.media.startedAt,stoppedAt:state.media.stoppedAt,interior:Boolean(state.media.blobs.interior),exterior:Boolean(state.media.blobs.exterior)},
    incidents:mediaTimelineItems().map(f=>({id:f.id,time:f.time,relativeSec:f.relativeSec,severity:f.severity,code:f.code,title:f.title,skills:f.skills,evidenceWindow:f.evidenceWindow,position:f.position}))
  };
  const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'});
  downloadBlob(blob,`DriveCoach_cronologia_${($('#student').value.trim()||'alumne').replace(/[^a-z0-9à-ÿ_-]+/gi,'_')}.json`);
}

function v19EvidenceAnalysis(f){
  const recent=state.faults.slice(-8);
  const same=recent.filter(x=>x.code===f.code).length;
  const skillCounts={};
  recent.forEach(x=>(x.skills||[]).forEach(k=>skillCounts[k]=(skillCounts[k]||0)+1));
  const ranked=Object.entries(skillCounts).sort((a,b)=>b[1]-a[1]);
  const primary=(f.skills||[])[0];
  const skillName=primary&&SKILL_META[primary]?SKILL_META[primary][1]:'Competència no assignada';
  const context=[];
  if(f.position) context.push(`GPS disponible (precisió aproximada ${Math.round(f.position.accuracy||0)} m)`);
  else context.push('GPS no disponible');
  context.push(`marca temporal +${formatDuration(f.relativeSec)}`);
  context.push(`finestra d’evidència ${formatDuration(f.evidenceWindow?.startSec||0)} → ${formatDuration(f.evidenceWindow?.endSec||f.relativeSec+10)}`);
  const checks={
    OBS:['Abans de l’acció: comprovar miralls i angle mort.','Preguntar a l’alumne què havia vist abans d’actuar.'],
    CAN:['Revisar la seqüència d’observació, senyalització, comprovació i desplaçament.','Comprovar si el desplaçament es va iniciar amb marge suficient.'],
    SIG:['Comprovar moment, durada i coherència de la senyalització.','Distingir si el problema és de decisió, senyalització o comprovació.'],
    CIR:['Revisar posició, trajectòria i adaptació a l’entorn.','Comprovar si la velocitat era adequada al context.'],
    DIS:['Revisar marge frontal i lateral disponible.','Comprovar si la distància es va adaptar a la situació.'],
    MAN:['Revisar control de volant, pedals i canvi.','Evitar corregir massa elements alhora.'],
    PAR:['Dividir la maniobra en passos i comprovar anticipació.','Revisar referències i control de l’espai.'],
    DEC:['Preguntar què va detectar, quines opcions va valorar i per què va actuar.','Revisar anticipació i marge de seguretat.'],
    SEG:['Prioritzar la reducció del risc abans del detall tècnic.','Revisar què hauria evitat l’exposició al risc.']
  };
  const guide=(checks[primary]||['Descriure què es veu abans d’interpretar-ho.','Preguntar a l’alumne què va percebre i quina decisió va prendre.']);
  return {
    version:'V19', generatedAt:new Date().toISOString(), student:$('#student')?.value.trim()||'',
    evidence:{id:f.id,severity:f.severity,code:f.code,title:f.title,relativeSec:f.relativeSec,window:f.evidenceWindow,skills:f.skills||[],position:f.position||null},
    objectiveContext:context,
    repeatedInRecentSessions: state.faults.filter(x=>x.code===f.code).length,
    recentSameCode:same,
    dominantRecentSkills:ranked.slice(0,3).map(([k,n])=>({skill:k,name:SKILL_META[k]?.[1]||k,count:n})),
    primaryCompetence:skillName,
    videoReviewGuide:guide,
    pedagogicalPrompt: primary==='DEC'?'Què vas veure? Quines opcions tenies? Què et va fer decidir?':'Què vas veure abans de fer l’acció i què vas comprovar?',
    limitation:'Anàlisi local estructurada: no determina contingut visual del vídeo ni atribueix intencions.'
  };
}
function renderV19Analysis(a){
 const host=$('#v19Summary'); if(!host||!a)return;
 host.innerHTML=`<div class="v19-grid">
   <article><b>📌 Incidència</b><strong>${escapeHtml(a.evidence.code)} · ${escapeHtml(a.evidence.severity)}</strong><span>${escapeHtml(a.evidence.title)}</span></article>
   <article><b>🧠 Competència principal</b><strong>${escapeHtml(a.primaryCompetence)}</strong><span>${a.evidence.skills.length} competència/es associada/es</span></article>
   <article><b>🔁 Repetició</b><strong>${a.recentSameCode}×</strong><span>en les últimes ${Math.min(8,state.faults.length)} incidències</span></article>
   <article><b>⏱️ Evidència</b><strong>${formatDuration(a.evidence.window.startSec)} → ${formatDuration(a.evidence.window.endSec)}</strong><span>${a.objectiveContext.join(' · ')}</span></article>
 </div>
 <div class="v19-block"><h3>🔎 Guia de revisió</h3>${a.videoReviewGuide.map(x=>`<p>• ${escapeHtml(x)}</p>`).join('')}</div>
 <div class="v19-block"><h3>💬 Pregunta pedagògica</h3><p>${escapeHtml(a.pedagogicalPrompt)}</p></div>
 <div class="v19-block"><h3>📊 Competències dominants recents</h3><p>${a.dominantRecentSkills.length?a.dominantRecentSkills.map(x=>`${escapeHtml(x.name)} (${x.count})`).join(' · '):'—'}</p></div>`;
 $('#v19Status').textContent='ANÀLISI LOCAL';
}
let lastV19Analysis=null;
function runV19(){
 const f=latestFault(), host=$('#v19Summary'), status=$('#v19Status');
 if(!f){if(host)host.innerHTML='<div class="empty">Registra una incidència per preparar-ne l’anàlisi.</div>';if(status)status.textContent='LOCAL';return}
 lastV19Analysis=v19EvidenceAnalysis(f);renderV19Analysis(lastV19Analysis);
 state.events.push({id:makeId(),type:'v19_analysis',time:Date.now(),relativeSec:f.relativeSec,analysis:lastV19Analysis});save();
}
function exportV19(){
 if(!lastV19Analysis)runV19();
 if(!lastV19Analysis)return;
 const blob=new Blob([JSON.stringify(lastV19Analysis,null,2)],{type:'application/json'});
 downloadBlob(blob,`DriveCoach_V19_${lastV19Analysis.evidence.code}_${lastV19Analysis.evidence.relativeSec}s.json`);
}


/* V20 — Preparador multimodal local
   No envia dades a cap servei. Construeix un paquet estructurat perquè
   una futura IA multimodal pugui analitzar evidència verificable.
*/
function buildV20Package(){
 const student=($('#student')?.value||'').trim();
 const faults=state.faults.map(f=>({
   id:f.id,severity:f.severity,code:f.code,title:f.title,text:f.text,section:f.section,
   relativeSec:f.relativeSec,evidenceWindow:f.evidenceWindow||null,skills:f.skills||[],
   position:f.position||null,observation:f.observation||'',
   media:{
     audioAvailable:!!f.media?.audio,
     videoInteriorAvailable:!!f.media?.videoInterior,
     videoExteriorAvailable:!!f.media?.videoExterior,
     mediaRelativeSec:f.media?.mediaRelativeSec??null,
     localClipInterior:!!state.media.clips?.[f.id+':interior'],
     localClipExterior:!!state.media.clips?.[f.id+':exterior']
   }
 }));
 return {
   schemaVersion:'V20.0',
   createdAt:new Date().toISOString(),
   privacy:{processing:'local',networkUpload:false,externalAI:false},
   student:student||'No especificat',
   licence:$('#licence')?.value||'',
   session:{sessionStarted:state.sessionStarted,examStarted:state.examStarted,examFinished:state.examFinished,
     durationMinutes:state.durationMinutes,gpsTrack:state.gpsTrack||[]},
   dgtReference:{database:'dgt_faults_mar2026.json',criteria:'CRITERIOS-DE-CALIFICACION-MARZO-2026.pdf'},
   evidence:faults,
   multimodalInputs:{
     audio:state.media.recorders?.some(x=>x.key==='audio')||false,
     interiorVideo:state.media.recorders?.some(x=>x.key==='interior')||!!state.media.blobs?.interior,
     exteriorVideo:state.media.recorders?.some(x=>x.key==='exterior')||!!state.media.blobs?.exterior,
     gps:!!state.gpsTrack?.length
   },
   aiContract:{
     mustSeparate:['observations','uncertainties','dgtRelation','skills','pedagogicalSuggestions'],
     mustNot:['invent_visual_facts','infer_intentions','change_DGT_barem','issue_exam_result_without_teacher'],
     teacherIsFinalDecisionMaker:true
   }
 };
}
function renderV20PackageStatus(){
 const host=$('#v20PackageStatus'); if(!host)return;
 const p=buildV20Package();
 host.innerHTML=`<b>📦 Paquet preparat:</b> ${p.evidence.length} incidència/es ·
 ${p.multimodalInputs.gps?'GPS':'sense GPS'} ·
 ${p.multimodalInputs.interiorVideo?'vídeo interior':'sense vídeo interior'} ·
 ${p.multimodalInputs.exteriorVideo?'vídeo exterior':'sense vídeo exterior'} ·
 <b>processament local</b>`;
}
function exportV20Package(){
 const p=buildV20Package();
 const blob=new Blob([JSON.stringify(p,null,2)],{type:'application/json'});
 downloadBlob(blob,`DriveCoach_V20_multimodal_${Date.now()}.json`);
 renderV20PackageStatus();
}
function copyV20Package(){
 const p=JSON.stringify(buildV20Package(),null,2);
 navigator.clipboard?.writeText(p).then(()=>{
   const s=$('#v20CopyStatus');if(s)s.textContent='Paquet copiat al porta-retalls.';
 }).catch(()=>{const s=$('#v20CopyStatus');if(s)s.textContent='No s’ha pogut copiar; utilitza Exportar paquet.'});
}

async function load(){state.data=await fetch('dgt_faults_mar2026.json').then(r=>{if(!r.ok)throw Error('No es troba la base DGT');return r.json()});loadSession();renderSections();render();renderFaults();renderCounters();renderSkillMap();renderEventStatus();renderEvidence();renderMediaTimeline();assistantRecommendation();renderVoiceControls();setGpsUI();updateMediaButtons();renderV20PackageStatus();renderDrivingContext();tick();state.timer=setInterval(()=>{tick();renderDrivingContext()},1000)}
load().catch(e=>{
  console.error('DriveCoach load error:',e);
  const status=$('#status'); if(status) status.textContent='Error de càrrega';
  const criteria=$('#criteria'); if(criteria) criteria.innerHTML=`<div class="empty">No s'ha pogut carregar la base DGT. Recarrega la pàgina. Detall: ${escapeHtml(e.message||e)}</div>`;
  // Keep the basic session controls usable even if optional data failed.
  try{updatePhaseUI();tick();}catch(err){console.error(err)}
});


// V21 — Assistent en temps real sota control del professor
(function(){
  const KEY='drivecoach-realtime-v21';
  const state=Object.assign({enabled:false,paused:false,level:'priority'}, JSON.parse(localStorage.getItem(KEY)||'{}'));
  const $=id=>document.getElementById(id);
  const enabled=$('realtimeEnabled'), paused=$('realtimePause'), level=$('realtimeLevel'), status=$('realtimeStatus');
  const title=$('realtimeTitle'), text=$('realtimeText'), card=$('realtimeCard'), mute=$('realtimeMute');
  if(!enabled||!paused||!level) return;
  enabled.checked=!!state.enabled; paused.checked=!!state.paused; level.value=state.level;
  function render(){
    const active=state.enabled&&!state.paused&&state.level!=='off';
    status.textContent=active?'ACTIVAT':'DESACTIVAT';
    status.classList.toggle('active',active);
    if(!state.enabled){ title.textContent='Assistent desactivat'; text.textContent='No farà cap intervenció automàtica. Les incidències continuen registrant-se normalment.'; card.querySelector('.assistant-icon').textContent='⏸️'; }
    else if(state.paused){ title.textContent='Assistent en pausa'; text.textContent='Pausa temporal activada pel professor. El registre de la sessió continua.'; card.querySelector('.assistant-icon').textContent='⏸️'; }
    else if(state.level==='off'){ title.textContent='Intervenció automàtica desactivada'; text.textContent='L’assistent pot romandre disponible, però no farà intervencions.'; card.querySelector('.assistant-icon').textContent='🔇'; }
    else { title.textContent='Assistent actiu'; text.textContent='DriveCoach només podrà intervenir segons el nivell seleccionat pel professor.'; card.querySelector('.assistant-icon').textContent='🟢'; }
    mute.textContent=state.paused?'▶ Reprendre assistent':'⏸ Pausar assistent';
    localStorage.setItem(KEY,JSON.stringify(state));
    window.DriveCoachRealtime={active,config:{...state}};
  }
  enabled.addEventListener('change',()=>{state.enabled=enabled.checked; if(!state.enabled) state.paused=false; render();});
  paused.addEventListener('change',()=>{state.paused=paused.checked; render();});
  level.addEventListener('change',()=>{state.level=level.value; render();});
  mute.addEventListener('click',()=>{state.paused=!state.paused; paused.checked=state.paused; render();});
  render();
})();
