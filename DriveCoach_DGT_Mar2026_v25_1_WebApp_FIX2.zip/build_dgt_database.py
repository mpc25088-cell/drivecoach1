import json, re, hashlib
from pathlib import Path
import pdfplumber

PDF = Path(__file__).with_name('CRITERIOS-DE-CALIFICACION-MARZO-2026.pdf')
OUT = Path(__file__).with_name('dgt_criteria_mar2026.json')

def norm(s):
    return re.sub(r'\s+', ' ', s or '').strip()

def section_match(text):
    m = re.match(r'^(\d+(?:\.\d+)*\.?)\s*-?\s*(.*)$', text.strip())
    if not m: return None
    code, title = m.groups()
    if not re.match(r'^\d', code): return None
    return code.rstrip('.'), norm(title)

entries=[]
with pdfplumber.open(PDF) as pdf:
    for page_no, page in enumerate(pdf.pages, start=1):
        words=page.extract_words(x_tolerance=1.5,y_tolerance=2,keep_blank_chars=False)
        # Group words into visual lines.
        lines=[]
        for w in sorted(words,key=lambda z:(z['top'],z['x0'])):
            placed=False
            for line in lines[-3:]:
                if abs(line['top']-w['top']) <= 2.5:
                    line['words'].append(w); placed=True; break
            if not placed: lines.append({'top':w['top'],'words':[w]})
        for line in lines:
            ws=sorted(line['words'],key=lambda z:z['x0'])
            left=norm(' '.join(w['text'] for w in ws if w['x0']<205))
            if not left: continue
            # Only headings in the left column, excluding page boilerplate.
            m=re.match(r'^(\d+(?:\.\d+)*\.?)(?:\s*-?\s*)(.*)$',left)
            if not m: continue
            code=m.group(1).rstrip('.')
            title=norm(m.group(2))
            if code in {'1','2','3','4','5','6','7','8','9','10','11','12','13','14','15'} or '.' in code:
                if title and title.upper() not in {'COMPROBACIONES PREVIAS.','INCORPORACIÓN A LA','PROGRESIÓN NORMAL.','DESPLAZAMIENTOS','ADELANTAMIENTOS.','INTERSECCIONES.','CAMBIO DE SENTIDO.','PARADAS Y','OBEDIENCIA DE LAS','LUCES.','MANEJO DE MANDOS.','OTROS MANDOS Y','DURANTE EL DESARROLLO'}:
                    cols={"eliminatorias":[],"deficientes":[],"leves":[],"notas":[]}
                    for w in ws:
                        x=w['x0']; t=w['text']
                        if 205<=x<392: cols['eliminatorias'].append(t)
                        elif 392<=x<558: cols['deficientes'].append(t)
                        elif 558<=x<675: cols['leves'].append(t)
                        elif x>=675: cols['notas'].append(t)
                    entries.append({
                        'id': f'{code.replace(".","-")}-p{page_no}',
                        'code': code,
                        'title': title,
                        'page': page_no,
                        'eliminatorias': norm(' '.join(cols['eliminatorias'])),
                        'deficientes': norm(' '.join(cols['deficientes'])),
                        'leves': norm(' '.join(cols['leves'])),
                        'notas': norm(' '.join(cols['notas']))
                    })

# Deduplicate visual fragments while retaining page/source provenance.
seen=set(); clean=[]
for e in entries:
    key=(e['code'],e['title'],e['eliminatorias'],e['deficientes'],e['leves'],e['notas'])
    if key not in seen:
        seen.add(key); clean.append(e)

pdf_hash=hashlib.sha256(PDF.read_bytes()).hexdigest()
out={
 'source': {'name':PDF.name,'edition':'MARZO 2026','sha256':pdf_hash,'official_source':'DGT','extracted_with':'pdfplumber coordinate extraction'},
 'baremo': [
  {'pattern':'E','result':'NO APTO','description':'Una falta eliminatoria'},
  {'pattern':'DD','result':'NO APTO','description':'Dos faltas deficientes'},
  {'pattern':'DLLLLL','result':'NO APTO','description':'Una deficiente y cinco leves'},
  {'pattern':'LLLLLLLLLL','result':'NO APTO','description':'Diez leves'}
 ],
 'entries': clean
}
OUT.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print(f'Generated {len(clean)} structured epigraph records -> {OUT}')
