import pdfplumber, re, json, hashlib
from pathlib import Path
PDF=Path(__file__).with_name('CRITERIOS-DE-CALIFICACION-MARZO-2026.pdf')
OUT=Path(__file__).with_name('dgt_faults_mar2026.json')

def norm(s):
    return re.sub(r'\s+', ' ', s.replace('\u00ad','')).strip()

def line_groups(words, tol=3):
    groups=[]
    for w in sorted(words,key=lambda z:(z['top'],z['x0'])):
        if not groups or abs(w['top']-groups[-1][0])>tol:
            groups.append([w['top'],[]])
        groups[-1][1].append(w)
    return groups

records=[]
current_section=''
current=None
# table pages start at PDF page 4 (index 3), continue through final page
with pdfplumber.open(PDF) as pdf:
  for pageno,page in enumerate(pdf.pages,1):
    if pageno < 4: continue
    words=page.extract_words(x_tolerance=1,y_tolerance=2,keep_blank_chars=False)
    # group by visual line, then assign each word to column
    lines=[]
    for top,ws in line_groups(words,3):
      cols={k:[] for k in ['epi','e','d','l','n']}
      # Stable table boundaries in the PDF: EPIGRAFE 25-182, E 182-342,
      # D 342-502, L 502-662, NOTES 662-820. Text is extracted inside its
      # visual cell; the first x-coordinate is therefore the reliable signal.
      for w in ws:
        x=w['x0']
        if x < 182: c='epi'
        elif x < 342: c='e'
        elif x < 502: c='d'
        elif x < 662: c='l'
        else: c='n'
        cols[c].append(w)
      text={k:norm(' '.join(w['text'] for w in cols[k])) for k in cols}
      starts={k:(min((w['x0'] for w in cols[k]), default=None)) for k in cols}
      lines.append((top,text,starts))

    # detect epigraph code at left column. decimal codes are the actual criteria;
    # integer X.- rows are section headers.
    for idx,(top,text,starts) in enumerate(lines):
      m=re.match(r'^(\d+(?:\.\d+)+)\.?\s*(.*)$',text['epi'])
      sec=re.match(r'^(\d+)\.\-?\s*(.*)$',text['epi'])
      if m:
        if current:
          records.append(current)
        code=m.group(1)
        title=norm(m.group(2)).lstrip('- ').strip()
        current={'code':code,'title':title,'section':current_section,'page':pageno,
                 'cells':{'E':[],'D':[],'L':[],'NOTES':[]}}
      elif sec and not re.match(r'^\d+\.\d+',text['epi']):
        current_section=norm(sec.group(2))
        if current:
          current['section']=current_section
      if current:
        # append content to the current criterion, preserving line boundaries.
        for key,col in [('E','e'),('D','d'),('L','l'),('NOTES','n')]:
          if text[col]: current['cells'][key].append((top,text[col],starts[col]))
    # page footer will not create data; next epigraph closes record.
  if current: records.append(current)

# Turn cell lines into selectable fault statements. A new statement begins when the
# line starts near the cell's left margin, or with a bullet. Wrapped lines are joined.
def statements(lines, col):
    if not lines: return []
    base=min(x for _,_,x in lines if x is not None)
    out=[]; buf=''; colon_list=False
    junk={'F. ELIMINATORIAS','F. DEFICIENTES','F. LEVES','NOTAS ACLARATORIAS'}
    for top,t,x in lines:
      t=norm(t)
      if not t or t.upper() in junk or any(j in t.upper() for j in junk) or re.fullmatch(r'\d+',t):
        continue
      t=re.sub(r'(?<=\w)-\s+(?=\w)', '', t)
      bullet=t.startswith('-')
      t=t.lstrip('- ').strip()
      starts_at_margin=(x is not None and x <= base+7)
      if bullet and buf.rstrip().endswith(':'):
        colon_list=True
      # Once a colon-led bullet list starts, subsequent bullets belong to the same fault.
      if bullet and colon_list:
        new_item=False
      else:
        complete=bool(re.search(r'[.!?…:]$',buf))
        new_item=starts_at_margin and bool(buf) and complete
        if bullet and buf and not colon_list:
          new_item=True
      if new_item:
        out.append(norm(buf)); buf=''; colon_list=False
      buf=(buf+' '+t).strip()
    if buf: out.append(norm(buf))
    return [re.sub(r'(?<=\w)-\s+(?=\w)', '', s) for s in out if s]

faults=[]
for r in records:
    f={"code":r['code'],"title":r['title'],"section":r['section'],"source_page":r['page'],"faults":[]}
    for sev,key in [('E','E'),('D','D'),('L','L')]:
      for i,s in enumerate(statements(r['cells'][key],key),1):
        # avoid obvious column header/footer noise
        if s.upper() in {'F. ELIMINATORIAS','F. DEFICIENTES','F. LEVES'}: continue
        f['faults'].append({'id':f"{r['code'].replace('.','_')}_{sev}_{i}",'severity':sev,'text':s})
    f['notes']=statements(r['cells']['NOTES'],'NOTES')
    if f['faults'] or f['notes']:
      faults.append(f)

raw=PDF.read_bytes()
out={
 'source':{'file':PDF.name,'edition':'MARZO 2026','sha256':hashlib.sha256(raw).hexdigest()},
 'baremo':{'E':1,'D':2,'D_plus_L':{'D':1,'L':5},'L':10},
 'criteria_count':len(faults),
 'fault_count':sum(len(x['faults']) for x in faults),
 'criteria':faults
}
OUT.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print('criteria',len(faults),'faults',out['fault_count'])
for x in faults[:12]:
 print('\n',x['code'],x['title'],x['section'])
 for f in x['faults']: print(' ',f['severity'],f['text'])
