import pdfplumber, re, json, hashlib
from pathlib import Path
PDF=Path(__file__).with_name('CRITERIOS-DE-CALIFICACION-MARZO-2026.pdf')
OUT=Path(__file__).with_name('dgt_faults_mar2026.json')

def norm(s):
    return re.sub(r'\s+', ' ', s.replace('\u00ad','')).strip()

def line_groups(words, tol=3):
    groups=[]
    for w in sorted(words,key=lambda z:(z['top'],z['x0'])):
        if not groups or abs(w['top']-groups[-1][0])>tol:
            groups.append([w['top'],[]])
        groups[-1][1].append(w)
    return groups

records=[]
current_section=''
current=None
# table pages start at PDF page 4 (index 3), continue through final page
with pdfplumber.open(PDF) as pdf:
  for pageno,page in enumerate(pdf.pages,1):
    if pageno < 4: continue
    words=page.extract_words(x_tolerance=1,y_tolerance=2,keep_blank_chars=False)
    # group by visual line, then assign each word to column
    lines=[]
    for top,ws in line_groups(words,3):
      cols={k:[] for k in ['epi','e','d','l','n']}
      # The PDF lets text in a cell extend slightly beyond its nominal column.
      # Cluster words by large horizontal gaps first, then classify each cluster.
      clusters=[]; cur=[]; prev_x1=None
      for w in ws:
        if cur and w['x0']-prev_x1 > 25:
          clusters.append(cur); cur=[]
        cur.append(w); prev_x1=w['x1']
      if cur: clusters.append(cur)
      for cl in clusters:
        x=cl[0]['x0']
        if x < 178: c='epi'
        elif x < 360: c='e'
        elif x < 505: c='d'
        elif x < 660: c='l'
        else: c='n'
        cols[c].extend(cl)
      text={k:norm(' '.join(w['text'] for w in cols[k])) for k in cols}
      starts={k:(min((w['x0'] for w in cols[k]), default=None)) for k in cols}
      lines.append((top,text,starts))

    # detect epigraph code at left column. decimal codes are the actual criteria;
    # integer X.- rows are section headers.
    for idx,(top,text,starts) in enumerate(lines):
      m=re.match(r'^(\d+(?:\.\d+)+)\.?\s*(.*)$',text['epi'])
      sec=re.match(r'^(\d+)\.\-?\s*(.*)$',text['epi'])
      if m:
        if current:
          records.append(current)
        code=m.group(1)
        title=norm(m.group(2))
        current={'code':code,'title':title,'section':current_section,'page':pageno,
                 'cells':{'E':[],'D':[],'L':[],'NOTES':[]}}
      elif sec and not re.match(r'^\d+\.\d+',text['epi']):
        current_section=norm(sec.group(2))
        if current:
          current['section']=current_section
      if current:
        # append content to the current criterion, preserving line boundaries.
        for key,col in [('E','e'),('D','d'),('L','l'),('NOTES','n')]:
          if text[col]: current['cells'][key].append((top,text[col],starts[col]))
    # page footer will not create data; next epigraph closes record.
  if current: records.append(current)

# Turn cell lines into selectable fault statements. A new statement begins when the
# line starts near the cell's left margin, or with a bullet. Wrapped lines are joined.
def statements(lines, col):
    if not lines: return []
    base=min(x for _,_,x in lines if x is not None)
    out=[]; buf=''
    junk={'F. ELIMINATORIAS','F. DEFICIENTES','F. LEVES','NOTAS ACLARATORIAS'}
    for top,t,x in lines:
      t=norm(t)
      if not t or t.upper() in junk or re.fullmatch(r'\d+',t):
        continue
      bullet=t.startswith('-')
      t=t.lstrip('- ').strip()
      # A new item is indicated by a bullet, or by a new line at the cell margin
      # after a complete sentence. Wrapped lines stay attached.
      starts_at_margin=(x is not None and x <= base+7)
      complete=bool(re.search(r'[.!?…:]$',buf))
      new_item=bullet or (starts_at_margin and bool(buf) and complete)
      if new_item:
        out.append(norm(buf)); buf=''
      buf=(buf+' '+t).strip()
    if buf: out.append(norm(buf))
    return [s for s in out if s]

for rr in records:
 if rr['code']=='3.3':
  print('DEBUG 3.3', {k:[v[1] for v in vals] for k,vals in rr['cells'].items()})
faults=[]
for r in records:
    f={"code":r['code'],"title":r['title'],"section":r['section'],"source_page":r['page'],"faults":[]}
    for sev,key in [('E','E'),('D','D'),('L','L')]:
      for i,s in enumerate(statements(r['cells'][key],key),1):
        # avoid obvious column header/footer noise
        if s.upper() in {'F. ELIMINATORIAS','F. DEFICIENTES','F. LEVES'}: continue
        f['faults'].append({'id':f"{r['code'].replace('.','_')}_{sev}_{i}",'severity':sev,'text':s})
    f['notes']=statements(r['cells']['NOTES'],'NOTES')
    if f['faults'] or f['notes']:
      faults.append(f)

raw=PDF.read_bytes()
out={
 'source':{'file':PDF.name,'edition':'MARZO 2026','sha256':hashlib.sha256(raw).hexdigest()},
 'baremo':{'E':1,'D':2,'D_plus_L':{'D':1,'L':5},'L':10},
 'criteria_count':len(faults),
 'fault_count':sum(len(x['faults']) for x in faults),
 'criteria':faults
}
OUT.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print('criteria',len(faults),'faults',out['fault_count'])
for x in faults[:12]:
 print('\n',x['code'],x['title'],x['section'])
 for f in x['faults']: print(' ',f['severity'],f['text'])
