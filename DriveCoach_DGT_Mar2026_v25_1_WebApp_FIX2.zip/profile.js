const KEY='drivecoach_students_v12';
const SKILL_META={OBS:['👀','Observació'],CAN:['🔄','Canvis de direcció / desplaçaments'],SIG:['🚦','Senyalització'],CIR:['🛣️','Circulació'],DIS:['↔️','Distàncies'],MAN:['⚙️','Maneig del vehicle'],PAR:['🅿️','Maniobres'],DEC:['🧠','Presa de decisions'],SEG:['⚠️','Seguretat']};
const loadDB=()=>{try{return JSON.parse(localStorage.getItem(KEY)||'{}')}catch{return {}}};
const saveDB=x=>localStorage.setItem(KEY,JSON.stringify(x));
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const skills=()=>Object.keys(SKILL_META);
function sessionData(){let s={};try{s=JSON.parse(localStorage.getItem('drivecoach-session')||'{}')}catch{} const faults=Array.isArray(s.faults)?s.faults:[];const counts={E:0,D:0,L:0};faults.forEach(f=>counts[f.severity]++);const sk=Object.fromEntries(skills().map(k=>[k,{E:0,D:0,L:0,total:0}]));faults.forEach(f=>(f.skills||[]).forEach(k=>{if(sk[k]){sk[k].total++;sk[k][f.severity]++}}));const started=s.examStarted||s.sessionStarted,finished=s.examFinished;const durationSec=started&&finished?Math.max(0,Math.floor((finished-started)/1000)):null;const no=counts.E>=1||counts.D>=2||(counts.D>=1&&counts.L>=5)||counts.L>=10;return {id:crypto.randomUUID(),name:(document.querySelector('#student')?.value||'').trim(),date:finished?new Date(finished).toISOString():new Date().toISOString(),durationSec,targetMinutes:Number(s.durationMinutes)||25,licence:s.licence||'B',...counts,total:faults.length,result:no?'NO APTE':'APTE',faults,skills:sk};}
function score(x){return x.total+x.D*2+x.E*4}
function skillTrend(a,k){const vals=a.map(x=>x.skills?.[k]?.total||0);if(vals.length<2)return {label:'Punt de partida',cls:'neutral',delta:0};const n=Math.min(3,Math.floor(vals.length/2));if(!n)return {label:'Punt de partida',cls:'neutral',delta:0};const recent=vals.slice(-n),prev=vals.slice(-(2*n),-n);const r=recent.reduce((a,b)=>a+b,0)/recent.length,p=prev.reduce((a,b)=>a+b,0)/prev.length;const delta=p-r;if(delta>=.75)return {label:'Millora',cls:'good',delta};if(delta<=-.75)return {label:'Empitjorament',cls:'bad',delta};return {label:'Estable',cls:'neutral',delta};}
function statusFor(a,k){const x=a.at(-1)?.skills?.[k]||{total:0,E:0,D:0,L:0};const tr=skillTrend(a,k);if(x.E>0||x.D>=2||x.total>=4)return ['🔴','Prioritat',tr];if(x.total>=2)return ['🟠','Necessita treball',tr];if(x.total===1)return ['🟡','En evolució',tr];return ['🟢','Consolidada',tr];}
function trendText(vals){if(vals.length<2)return 'Punt de partida';const d=score(vals.at(-1))-score(vals[0]);if(d<=-2)return 'Millora';if(d>=2)return 'Empitjorament';return 'Estable'}
function patterns(a){const out=[];skills().forEach(k=>{const appearances=a.map((x,i)=>({x,i})).filter(o=>(o.x.skills?.[k]?.total||0)>0);if(appearances.length>=3){const recent=appearances.slice(-5).length;out.push({k,count:appearances.length,recent,label:`${SKILL_META[k][1]} apareix en ${appearances.length} sessions`})}});const codes={};a.forEach((s,si)=>(s.faults||[]).forEach(f=>{const key=f.code+'|'+f.text;(codes[key]??=[]).push(si+1)}));Object.entries(codes).filter(([,v])=>v.length>=3).forEach(([key,v])=>{const [code,text]=key.split('|');out.push({code,text,count:v.length,sessions:v})});return out.sort((a,b)=>(b.count||0)-(a.count||0));}
function plan(a){const last=a.at(-1);return skills().map(k=>{const [icon,name,tr]=statusFor(a,k);const current=last?.skills?.[k]?.total||0;const repeated=a.filter(x=>(x.skills?.[k]?.total||0)>0).length;let action='Mantenir i verificar';if(tr.label==='Millora')action='Consolidar la millora amb situacions variades';if(tr.label==='Empitjorament')action='Treball prioritari i reducció de càrrega';if(current>=2||repeated>=3)action='Exercicis específics i feedback immediat';return {k,icon,name,status:tr.label,action,current,repeated,priority:icon==='🔴'||tr.label==='Empitjorament'}}).sort((a,b)=>Number(b.priority)-Number(a.priority)||b.current-a.current);}

function localPedagogicalAnalysis(a){
 const last=a.at(-1)||{}, prev=a.length>1?a.at(-2):null;
 const skillRows=skills().map(k=>{
   const cur=last.skills?.[k]||{E:0,D:0,L:0,total:0};
   const vals=a.map(x=>x.skills?.[k]?.total||0);
   const tr=skillTrend(a,k);
   const appearances=a.filter(x=>(x.skills?.[k]?.total||0)>0).length;
   const recent=a.slice(-5).filter(x=>(x.skills?.[k]?.total||0)>0).length;
   const severity=(cur.E*4)+(cur.D*2)+cur.L;
   return {k,name:SKILL_META[k][1],icon:SKILL_META[k][0],cur,tr,appearances,recent,severity,priority:cur.E>0||cur.D>=2||cur.total>=4||tr.label==='Empitjorament'};
 }).sort((a,b)=>Number(b.priority)-Number(a.priority)||b.severity-a.severity);
 const priorities=skillRows.filter(x=>x.priority).slice(0,3);
 const repeated=[];
 const codes={};
 a.forEach((ss,si)=>(ss.faults||[]).forEach(f=>{
   const key=f.code+'|'+f.text;
   (codes[key]??=[]).push(si+1);
 }));
 Object.entries(codes).forEach(([key,sessions])=>{
   if(sessions.length>=3){const [code,text]=key.split('|');repeated.push({code,text,sessions,count:sessions.length});}
 });
 const patternsBySkill=skillRows.filter(x=>x.appearances>=3 && x.recent>=3);
 const recommendations=[];
 priorities.forEach(x=>{
   if(x.k==='OBS') recommendations.push('Treballar l’observació abans de qualsevol maniobra: miralls, entorn i angles morts.');
   else if(x.k==='CAN') recommendations.push('Practicar la seqüència observar → senyalitzar → comprovar → executar en canvis de direcció i desplaçaments.');
   else if(x.k==='SIG') recommendations.push('Reforçar el moment i la correcció de la senyalització abans d’iniciar la maniobra.');
   else if(x.k==='CIR') recommendations.push('Treballar posició, trajectòria i velocitat adaptada en situacions variades.');
   else if(x.k==='DIS') recommendations.push('Practicar separació frontal i lateral amb referències concretes i anticipació.');
   else if(x.k==='MAN') recommendations.push('Consolidar el maneig amb exercicis progressius, evitant que els controls interfereixin amb l’observació.');
   else if(x.k==='PAR') recommendations.push('Repetir les maniobres amb una seqüència estable d’observació, posicionament i execució.');
   else if(x.k==='DEC') recommendations.push('Treballar anticipació i presa de decisions amb més temps d’anàlisi abans d’actuar.');
   else if(x.k==='SEG') recommendations.push('Prioritzar conductes que redueixin el risc i revisar les incidències amb impacte en la seguretat.');
 });
 if(!recommendations.length) recommendations.push('No hi ha una prioritat crítica clara. Consolidar les competències estables i continuar observant la tendència.');
 const trend=trendText(a);
 let global='estable';
 if(trend==='Millora') global='positiva';
 if(trend==='Empitjorament') global='negativa';
 return {skillRows,priorities,repeated,patternsBySkill,recommendations,global,trend,
   nextSession:priorities.length?`Prioritzar ${priorities.map(x=>x.name).join(', ')} i comprovar si el patró es redueix en situacions variades.`:'Consolidar les fortaleses i introduir situacions variades per comprovar la transferència.'};
}
function renderLocalAI(a){
 const r=localPedagogicalAnalysis(a);
 const esc2=esc;
 const statusClass=r.global==='positiva'?'good':r.global==='negativa'?'bad':'neutral';
 const priorityHtml=r.priorities.length?r.priorities.map(x=>`<div class="ai-plan-item"><span>${x.icon}</span><div><b>${esc2(x.name)}</b><small>${esc2(x.tr.label)} · ${x.cur.total} incidències a l’última sessió · ${x.appearances}/${a.length} sessions</small></div></div>`).join(''):'<p class="empty">Cap prioritat crítica detectada.</p>';
 const recHtml=r.recommendations.map(x=>`<li>${esc2(x)}</li>`).join('');
 const patternHtml=[...r.repeated.map(p=>`<div class="ai-pattern">🔁 <b>${esc2(p.code)}</b> · ${esc2(p.text)} <small>${p.count} aparicions · sessions ${p.sessions.join(', ')}</small></div>`),...r.patternsBySkill.map(p=>`<div class="ai-pattern">🧩 <b>${esc2(p.name)}</b> <small>present en ${p.appearances} sessions; ${p.recent} de les últimes 5</small></div>`)].slice(0,6).join('');
 return `<div class="ai-card local-ai-head"><div><h3>🧠 Motor pedagògic local V14</h3><small>Sense API, servidor ni enviament de dades. Regles deterministes sobre l’historial local.</small></div><span class="trend-badge ${statusClass}">Tendència ${esc2(r.trend.toLowerCase())}</span></div>
 <div class="ai-card"><h3>🎯 Prioritats per a la propera sessió</h3><div class="ai-plan">${priorityHtml}</div><p class="next-session"><b>Proposta:</b> ${esc2(r.nextSession)}</p></div>
 <div class="ai-card"><h3>🔁 Patrons que mereixen seguiment</h3>${patternHtml||'<p>No hi ha prou repeticions persistents per generar un patró.</p>'}</div>
 <div class="ai-card"><h3>💡 Recomanacions pedagògiques</h3><ul class="ai-recommendations">${recHtml}</ul></div>
 <div class="ai-card ai-disclaimer"><b>Important:</b> aquesta anàlisi és una ajuda pedagògica. No és una nota, un diagnòstic ni una decisió d’examen; el professor manté el criteri final.</div>`;
}
function drawChart(canvas,a){const ctx=canvas.getContext('2d');const w=canvas.clientWidth||700,h=260,dpr=window.devicePixelRatio||1;canvas.width=w*dpr;canvas.height=h*dpr;ctx.scale(dpr,dpr);ctx.clearRect(0,0,w,h);const max=Math.max(1,...a.map(s=>s.total),...a.flatMap(s=>skills().map(k=>s.skills?.[k]?.total||0)));ctx.font='11px system-ui';ctx.fillStyle='#64748b';for(let i=0;i<=4;i++){const y=22+i*(h-48)/4;ctx.strokeStyle='#e5e7eb';ctx.beginPath();ctx.moveTo(36,y);ctx.lineTo(w-12,y);ctx.stroke();ctx.fillText(String(Math.round(max*(1-i/4))),8,y+4)};a.forEach((s,i)=>{const x=42+(w-58)*(a.length===1?.5:i/(a.length-1));ctx.fillStyle='#64748b';ctx.fillText('S'+(i+1),x-7,h-10)});const active=skills().filter(k=>a.some(s=>(s.skills?.[k]?.total||0)>0));active.forEach((k,ki)=>{ctx.strokeStyle=['#2563eb','#16a34a','#ea580c','#7c3aed','#0891b2','#dc2626','#ca8a04','#db2777','#4f46e5'][ki%9];ctx.lineWidth=2;ctx.beginPath();a.forEach((s,i)=>{const x=42+(w-58)*(a.length===1?.5:i/(a.length-1));const v=s.skills?.[k]?.total||0;const y=22+(max-v)*(h-48)/max;i?ctx.lineTo(x,y):ctx.moveTo(x,y)});ctx.stroke()});ctx.fillStyle='#334155';ctx.font='bold 11px system-ui';let lx=42;active.forEach(k=>{const m=SKILL_META[k];ctx.fillText(m[0]+' '+m[1],lx,14);lx+=Math.min(150,ctx.measureText(m[0]+' '+m[1]).width+28);if(lx>w-130){lx=42}})}
function render(){const db=loadDB(),list=document.querySelector('#studentList'),evo=document.querySelector('#studentEvolution');if(!list)return;const names=Object.keys(db).sort((a,b)=>a.localeCompare(b,'ca'));list.innerHTML=names.length?'<div class="student-picks">'+names.map(n=>`<button class="studentPick" data-name="${esc(n)}">${esc(n)}</button>`).join('')+'</div>':'<p style="opacity:.7">Encara no hi ha sessions guardades.</p>';list.querySelectorAll('.studentPick').forEach(b=>b.onclick=()=>show(b.dataset.name));if(names.length)show(names[0]);
function show(n){const a=db[n]||[];if(!a.length){evo.innerHTML='<p>Sense sessions registrades.</p>';return}const first=a[0],last=a.at(-1);const global=trendText(a);const rows=a.map((x,i)=>`<tr><td>${i+1}</td><td>${new Date(x.date).toLocaleDateString('ca-ES')}</td><td>${x.E}</td><td>${x.D}</td><td>${x.L}</td><td><b>${x.total}</b></td><td>${x.durationSec==null?'—':Math.floor(x.durationSec/60)+' min'}</td><td>${x.result}</td></tr>`).join('');const cards=skills().map(k=>{const [icon,name,tr]=statusFor(a,k);const cur=last.skills?.[k]?.total||0;const prev=a.length>1?(a.at(-2).skills?.[k]?.total||0):0;return `<article class="skill-card ${tr.cls}"><div class="skill-title"><span>${icon}</span><b>${name}</b><strong>${cur}</strong></div><div class="skill-breakdown"><span>Anterior ${prev}</span><span>E ${last.skills?.[k]?.E||0}</span><span>D ${last.skills?.[k]?.D||0}</span><span>L ${last.skills?.[k]?.L||0}</span></div><small><b>${tr.label}</b> · ${icon} ${name==='Consolidada'?'':name}</small></article>`}).join('');const pats=patterns(a);const planRows=plan(a).slice(0,5).map(p=>`<div class="plan-row ${p.priority?'priority':''}"><span>${p.icon}</span><div><b>${p.name}</b><small>${p.status} · ${p.current} incidències actuals · ${p.repeated} sessions amb incidències</small><p>${p.action}</p></div></div>`).join('');const patternHtml=pats.length?pats.slice(0,6).map(p=>p.code?`<div class="pattern-row">🔁 <b>${esc(p.code)}</b> · ${esc(p.text)} <strong>×${p.count}</strong><small>Sessions: ${p.sessions.join(', ')}</small></div>`:`<div class="pattern-row">🧩 <b>${esc(p.label)}</b><small>Present en ${p.count} sessions</small></div>`).join(''):'<p class="empty">Encara no hi ha prou historial per detectar patrons persistents.</p>';
evo.innerHTML=`<div class="profile-head"><div><h3>${esc(n)}</h3><p><b>${global==='Millora'?'📈':global==='Empitjorament'?'📉':'➡️'} ${global}</b> · ${first.total} → ${last.total} incidències · ${a.length} sessions</p></div><span class="profile-badge">V14</span></div><div class="profile-chart"><h3>📈 Evolució per competències</h3><canvas id="skillChart" aria-label="Gràfic d'evolució de competències"></canvas><small>Escala relativa d'incidències. Serveix per veure tendències, no és una nota.</small></div><div class="profile-ai-tools"><button id="runProfileAI" class="primary">🧠 Analitzar perfil amb motor local V14</button></div><div id="profileAIResults" class="profile-ai-results">${renderLocalAI(a)}</div><h3>Mapa d’habilitats actual</h3><div class="skill-grid">${cards}</div><div class="profile-columns"><section><h3>🔁 Patrons detectats</h3>${patternHtml}</section><section><h3>🎯 Pla de treball proposat</h3>${planRows}</section></div><h3>Historial de sessions</h3><div style="overflow:auto"><table class="history-table"><thead><tr><th>Sessió</th><th>Data</th><th>E</th><th>D</th><th>L</th><th>Total</th><th>Temps</th><th>Resultat</th></tr></thead><tbody>${rows}</tbody></table></div>`;drawChart(document.querySelector('#skillChart'),a);const aiBtn=document.querySelector('#runProfileAI');if(aiBtn)aiBtn.onclick=()=>{const host=document.querySelector('#profileAIResults');host.innerHTML=renderLocalAI(a);host.scrollIntoView({behavior:'smooth',block:'nearest'});};}
}
document.addEventListener('DOMContentLoaded',()=>{document.querySelector('#saveStudentBtn')?.addEventListener('click',()=>{const s=sessionData();if(!s.name)return alert('Introdueix el nom de l’alumne.');const db=loadDB();(db[s.name]??=[]).push(s);saveDB(db);document.querySelector('#studentNameInput').value=s.name;render();alert('Sessió guardada a l’historial.');});render();});
